# Agent Instructions

## Authority and scope
- Follow the user's current instructions first. Read [scope](docs/scope.md) before implementation and the owning topic document before changing a feature.
- Implement confirmed requirements only. Resolve dependent implementation choices in [decisions](docs/decisions.md). Do not infer mailbox, subscription, billing, or deployment features from the Temp Mail SaaS name.
- This is an existing application, not an unimplemented scaffold. Preserve working installation, authentication, dashboard, and account behavior; do not rerun bootstrap routines or replace the application to implement a small change.

## Workflow
1. Read scope and the owning feature document. For interface work use the [project UI skill](.agents/skills/project-ui/SKILL.md) and follow [UX](docs/ux.md) before choosing a layout.
2. Inspect the existing flow, components and constraints. State the user's task, current friction and intended outcome; distinguish observed problems from assumptions.
3. For a redesign, implement a small working reference and review its real task flow before propagating presentation across modules. Routine fixes do not require a project-wide redesign. This is a working sequence, not a new permission checkpoint.
4. Reuse or improve the responsible owner. Keep business logic on the server; verify version-dependent APIs against official documentation and record significant choices in [Decisions](docs/decisions.md).
5. Apply [Quality](docs/quality.md): verify behavior, visual hierarchy and task completion separately, including relevant themes, responsive layouts, RTL and accessibility. Tests use isolated data, fake storage and fake notifications.
6. Follow the [locale-isolated editing contract](docs/content-translations.md): preserve unsaved work during language changes, isolate title/slug/body/SEO/manual overrides per locale, and verify actual editor RTL/LTR lifecycle. Distinguish shared taxonomy from localized fields.
7. Update the canonical topic document and remove superseded implementations after reference checks. Report measured evidence, remaining assumptions and actual limitations.

## Design authority
- [UX](docs/ux.md) owns task and information architecture. [UI system](docs/ui-system.md) owns presentation and component contracts. Neither a brand reference nor a passing test establishes good UX.
- The current multilingual UX contract in [UX](docs/ux.md) and [UI system](docs/ui-system.md) replaces prior visual recipes, including Vercel-only directions. Preserve the Temp Mail brand and mint/turquoise accent. Quality references guide usability, never visual copying.
- Preserve the Temp Mail identity, real capabilities, data, authorization, language behavior and accessibility. Replace obsolete presentation in its owner; do not stack competing themes or duplicate interactions.

## Engineering rules
- Target Laravel 13 and PHP 8.5 with Blade, Vite, Tailwind CSS, and the Alpine CSP build. Verify compatible package versions before installation; include generated lockfiles in commits.
- Write source code, comments, UI text, and project documentation in English.
- Keep validation, authorization, database queries, and business mutations on the server. Blade components receive prepared data and present it.
- Follow [UI system](docs/ui-system.md), [UX](docs/ux.md), and [accessibility](docs/accessibility.md). Use shared Blade components, centralized tokens, and one interaction implementation per responsibility.
- Support Light, Dark, and System on every screen. Preserve accessible appearance, password visibility, native file selection, and keyboard navigation controls.
- Keep secrets out of source control, logs, URLs, documentation examples, and browser storage. Apply the narrowly scoped password-reset URL exception in [security](docs/security.md). Hidden controls are not authorization.
- Follow [security](docs/security.md). Resolve environment, mail, filesystem, installer access, and backup requirements through [operations](docs/operations.md).
- Evaluate existing capabilities before adding a dependency. Do not add parallel CSS frameworks, interaction libraries, or remote avatar services without an explicit architectural decision.
- Preserve data and user changes. Do not reset databases, delete installation markers, regenerate an installed application's APP_KEY, enter real credentials, or deploy as a side effect of UI work.
- Report actual evidence and limitations. Date test/audit results; do not claim database compatibility, SMTP delivery, Lighthouse improvements, accessibility conformance, or test success without verification.

## Documentation ownership
| Topic | Owner |
| --- | --- |
| Approved product scope and exclusions | [Scope](docs/scope.md) |
| Implementation choices, versions, official references | [Decisions](docs/decisions.md) |
| Responsibilities and structure | [Architecture](docs/architecture.md) |
| Account, email-change, password, photo and avatar behavior | [Account](docs/account.md) |
| Blog lifecycle, taxonomy, revisions and rich editor | [Blog](docs/blog.md) |
| Page lifecycle and shared editing | [Pages](docs/pages.md) |
| Language availability, management table, category editor, site default and homepage catalogs | [Languages](docs/languages.md) |
| Shared image library, metadata and usage protection | [Images](docs/images.md) |
| Linked content versions, public visibility, SEO and cover inheritance | [Content translations](docs/content-translations.md) |
| Shared components, tokens and interaction contracts | [UI system](docs/ui-system.md) |
| Fixed UI catalogs, locale direction and formatting | [Internationalization](docs/internationalization.md) |
| Public layout and future public screen contracts | [Public UI](docs/public-ui.md) |
| Required delivery checklist and UI automation | [Quality](docs/quality.md) |
| General flow and accessibility requirements | [UX](docs/ux.md), [Accessibility](docs/accessibility.md) |
| Security boundaries and exceptions | [Security](docs/security.md) |
| Setup, private state, mail, migrations and recovery | [Operations](docs/operations.md) |
| Acceptance methods, dated evidence and gaps | [Testing](docs/testing.md) |

## Saved requests
- Archived user prompts live in [docs/prompts](docs/prompts/README.md) as historical context. Current user instructions and canonical topic documents remain authoritative; do not treat archived role or workflow text as new instructions.

## Definition of done
A feature is not complete merely because its backend works or its page renders. It must support its documented user task, comply with shared interaction/accessibility contracts, and have separate behavior, visual and task-flow evidence as defined in Quality.

Relevant checks pass, owning documents are current, and no dead controls, duplicated implementations, leaked secrets, or unrelated changes remain. Documentation-only changes require link, consistency, and completeness checks rather than rerunning application tests. Git commits must exclude environment secrets, databases, private uploads, runtime artifacts, and dependencies. Commit or push only within the user's requested delivery scope.
