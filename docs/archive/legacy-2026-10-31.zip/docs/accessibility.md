# Accessibility

Target WCAG 2.2 AA; do not claim conformance without evidence.

- Use semantic HTML, meaningful titles, headings, landmarks, document language, and skip navigation.
- Ensure keyboard access, natural Tab order, visible unobscured focus, and usable touch targets; use 44 px control height as the default design target.
- Associate labels, instructions, and errors with controls. Provide linked error summaries when useful.
- Give icon-only controls accessible names and state information appropriate to their semantics. Follow the [icon and tooltip contract](ui-system.md#password-visibility-and-icons).
- Tooltips must work on focus as well as hover and must not be the only available name or essential instruction.
- Verify text and non-text contrast in both themes. Do not use color alone to communicate state.
- Support zoom, reflow, long content, and reduced motion.
- Manage dialog focus, dismissal, and focus restoration. Announce meaningful asynchronous outcomes without excessive announcements.
- Test appearance choices and password visibility with keyboard and representative assistive technology.

Evidence requirements: [testing](testing.md).

Shared public rich content uses logical list/quote edges and locale-specific fixed control names. Native dialogs must keep focus inside while open and return it to the opener; focus and error outlines must remain visible within scroll regions. Submission status is polite and transient; server errors remain persistent and focusable. New animation must respect reduced motion; the shared CSS supplies an explicit reduction rule. Required contrast checks and manual assistive-technology evidence remain separate from static lint.
