# Account

Current behavior reviewed on 2026-10-29. Scope approval is owned by [scope](scope.md), implementation choices by [decisions](decisions.md), and verification evidence by [testing](testing.md).

## Access and profile
Administrators and members manage their own account at /account. The controller uses the authenticated user; client-supplied user IDs, roles, file paths, and email values are not accepted by the profile-name mutation. Name is required, at most 255 characters. Email is displayed and changes only through the verified workflow below. The sidebar exposes Dashboard only to administrators and marks My account as current on this page.

## Password changes
Require the current password, a different new password of 12–1024 characters, and matching confirmation. Hash passwords using Laravel's configured hasher. Rotate remember tokens, regenerate the current session ID, and revoke other sessions through auth.session while preserving the current session. Never repopulate password fields or flash password values.

## Uploaded profile photos
Accept JPEG, PNG, and WebP images only, at most 2 MiB and 2048 pixels per dimension. Reject uploaded SVG, non-images, and disguised executable content. Use randomized server-controlled filenames on the private avatars disk. Only the current user's image can be served through the authenticated photo route; no public link or user-ID parameter grants access.

Users can upload, replace, or remove photos. Commit the new reference before deleting the previous private file. Serialize reference updates with a user-row lock. Failed writes preserve the old photo; failed cleanup can leave an inaccessible orphan requiring operator cleanup. Image re-encoding, malware scanning, cropping, and cloud storage are not implemented.

The file picker displays Browse and No file selected in English and retains the native labelled input and upload semantics. Without JavaScript it displays Choose a file and remains usable. The operating-system dialog language is controlled by the user's device.

## Preset avatars
Offer ten original inline SVG presets: Orbit, Leaf, Bolt, Peak, Wave, Star, Bloom, Moon, Spark, and Gem. The config/avatars.php allowlist is authoritative. Use labelled native radio controls, visible selected/focus states, fixed dimensions, and the shared semantic palette. Add no external avatar requests or JavaScript dependency.

Selecting a preset clears the uploaded-photo reference and cleans up its previous file after commit. Uploading a photo clears the preset; removal clears both. Show the name initial when neither is set. Avatar selection works without JavaScript.

## Verified email changes
1. Require a lowercase valid new email, at most 255 characters and not currently registered, plus the current account password.
2. Send a cryptographically generated six-digit code to the new address. Keep the existing login email unchanged until confirmation. Require a supported real mail transport; log/array transports cannot receive codes.
3. Store only a hash of the code in one pending request per user. Expire it after 10 minutes and allow at most five incorrect attempts. Persist failed-attempt increments even when returning validation errors.
4. Enforce a 60-second per-user resend cooldown plus route throttles. Resending requires the current password and generates a different code, invalidating the prior one. A delivery failure preserves prior pending state. A database failure after sending can leave the received code unusable; do not change the account or claim success.
5. Bind pending state to the existing email and password fingerprint. Changes to either invalidate the pending request. Confirmation accepts the code only, never a client-supplied user ID or target email. Users may cancel their own pending change.
6. Serialize send/confirm/cancel through the user-row lock. Recheck address availability at confirmation and retain the unique users.email constraint. On success update email and email_verified_at, consume the request, and regenerate the current session ID.
7. Notify the previous address after the change commits. A notification failure must not undo the confirmed address; show a distinct outcome stating that the previous-address notice could not be sent.

Codes and confirmation passwords must not appear in flashed input, URLs, logs, browser storage, or queued payloads. Notifications are synchronous. Expired requests cannot be used and are cleared on invalid confirmation; no background cleanup or mail retry service is configured. Security boundaries are owned by [security](security.md); transport and private-storage setup by [operations](operations.md).

## Settings presentation

/account renders Profile by default, with ordinary Profile, Security and Appearance links using an allowlisted section query. Only the selected section is rendered. A pending email change defaults to Security, while explicit section links remain usable. Validation errors take precedence so the affected section and native disclosure open automatically. Presentation-only account_section flash state keeps successful password/email operations in Security and avatar/profile operations in Profile; mutation URLs and security rules are unchanged.

Profile shows the current avatar, full name, current email and profile save action. Change avatar opens a native details panel containing the existing upload, ten preset radios and removal forms. Escape closes it and returns focus to its summary when JavaScript is enabled. A bounded JPEG/PNG/WebP upload can be previewed locally before saving; previews are not persisted and do not replace server validation. Preset thumbnails show each available choice. All avatar controls work without JavaScript.

Security has separate native disclosures for email and password changes. Pending-code confirmation appears before an optional Send a new code disclosure; resend errors open that disclosure too. Appearance reuses the existing Light/Dark/System preference owner and pre-paint bootstrap through the shared component settings variant. Without JavaScript, ordinary settings links and native disclosures keep account forms available; appearance follows the device palette and shows an explanation.

Profile, email, password and avatar mutation forms share submission progress and duplicate-click guards from the design foundation. Native payload controls remain enabled, preserving selected files, action values and no-JavaScript behavior. Existing server validation/session/email-change rules remain authoritative.
