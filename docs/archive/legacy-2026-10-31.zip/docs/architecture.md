# Architecture

Laravel 13 / PHP 8.5 own server behavior. Blade owns server-rendered layouts and reusable presentational components. Vite builds local assets. Tailwind CSS owns utility styling and the central theme configuration. Alpine.js owns client-side UI state and interactions.

Routes and middleware select and protect endpoints. Controllers coordinate validated requests and focused application actions. Models own persistence; policies enforce authorization. Blade receives prepared data without business queries or mutations.

Use the official Laravel Vite integration and Tailwind Vite plugin after package compatibility verification. Import Alpine through the bundled entry and initialize it once. Register reused interaction logic centrally; avoid copied Alpine expressions for complex behavior. Do not attach a second vanilla JavaScript handler to behavior already managed by Alpine. Small platform-specific helpers are allowed when justified, including early theme initialization.

Tailwind is the default styling mechanism. Focused custom CSS is allowed where utilities are unsuitable; it must use the same tokens and have one owner. Avoid dynamic fragments of Tailwind class names that the build cannot discover; use complete class mappings or the documented source mechanism for the selected version.

Use conventional Laravel structure and named routes. Add layers or dependencies only for demonstrated needs. Keep related persistence changes transactional, make consequential retries safe, and preserve existing data unless a destructive change is explicitly authorized.

Implemented database and installer decisions are recorded in [decisions](decisions.md). Deployment remains pending; operating requirements are in [operations](operations.md).

## Implemented responsibilities
InstallationController coordinates setup screens and validated requests; Installation owns connection verification, encrypted configuration, lease ownership and completion locking. AuthController handles session authentication and password-broker flows. DashboardController prepares the current administrator; route middleware and its Gate authorize access. AccountController owns self-service profile/password/photo/preset mutations; EmailChangeController owns the code lifecycle and synchronous notifications using EmailChange state. User and EmailChange hold persistence; Blade receives prepared view data. Canonical behavior is in [account](account.md), boundaries in [security](security.md), and private-state operations in [operations](operations.md).

BlogPostController and BlogTermController own admin-only content and taxonomy requests. BlogPost/BlogTerm hold persistence and relationships; RichTextDocument bounds/normalizes document structure and derives text. The editor module is dynamically imported from the Alpine component only on post and page forms and keeps the Tiptap instance outside Alpine's reactive proxy. Reused presentation remains in Blade, with no business query/mutation there. See [blog](blog.md) for behavior and [decisions](decisions.md) for the editor/data-format choice.

PageController and Page own page requests and persistence. RichTextDocument and x-rich-text-editor remain the single validation/editor owners. ContentTable prepares database pagination, eager-loaded metadata and counts for the shared content.index view. ContentActionController and ContentLifecycle own complete-selection lifecycle transitions, one-use confirmations, URL reservations and bounded revisions. BlogPost/Page share HasPublication with explicit UTC instants and SoftDeletes; linked versions keep their existing table. PublicContentController enforces active/published/due/non-trashed visibility, media relationships and sitemap output; ContentRenderer emits escaped validated nodes.

LanguageController coordinates administrator language requests; LanguageSetting stores the single site default and HomepageTranslation stores allowlisted overrides. SiteLanguages resolves fixed Laravel catalogs, English fallback and database overrides for the deferred homepage. Resolution is explicit and adds no setup/authentication boot query. The [Languages](languages.md) document owns behavior and exclusions.

ImageController/ImageLibrary own private media delivery, bounded decoding, WebP generation and metadata updates. Image/ImageTranslation/ImageUsage own assets, locale metadata and normalized references. ContentImages provides shared cover validation/resolution and transactional usage synchronization for both roots and translated versions. ContentTranslationController/ContentTranslation own linked language variants without moving existing English records. The installed Tiptap core Node API supplies one constrained mediaImage extension; no image package or second editor implementation is added. See [Images](images.md) and [Content translations](content-translations.md).

LanguageTable prepares filtered, sorted and paginated catalog rows and completeness without Blade queries. LanguageStatus owns transactional default/availability changes. LanguageIndexRequest and its mutation subclasses validate allowlisted table context and administrator access. Shared data-table, sortable-heading and optional detailed pagination components present prepared data; the tableSelection Alpine component owns page-local selection and submission guards.

SiteLanguages::entries owns translation provenance, editable target values and fallback resolution shared by the editor, resolver and table completion. Config metadata assigns existing source keys to categories without schema changes. x-translation-row presents prepared entries; translationEditor owns only client filtering, effective-value dirty tracking, reset and submission/navigation guards. LanguageController retains complete-key atomic persistence and validates actual Laravel source placeholders.

TermLifecycle owns transactional full-selection Trash/Restore/permanent deletion and category dependency protection. Post/Page/BlogTerm roots hold an immutable primary_locale; shared locale selectors, coverage and public resolution use that value rather than assuming English. ImageController::picker prepares bounded private library JSON for the existing coverImage interaction.

The design foundation keeps x-document-head as the single font/theme/Vite/meta owner, x-page-heading as the shared admin/auth heading and x-public-layout as the reader-facing shell. Existing layout/sidebar/editor/media/translation interaction owners remain. submitForm enhances otherwise unowned mutation forms only; x-submit-status presents its busy feedback. scripts/check-ui.mjs is a dependency-free source guard, not a replacement for server or rendered accessibility tests. No new business service, database migration or frontend package is introduced.

## Dashboard content overview — 2026-10-30

DashboardController prepares grouped non-trashed post lifecycle counts and the six most recently updated posts with translation counts. Blade presents these bounded results and named-route links. Static destination cards were retired; no analytics, mailbox or billing service was added.

## Locale editor navigation — 2026-10-30

resources/js/cms-locale-navigation.js coordinates only the existing Post/Page/linked editor routes. It retains per-locale native values, rich JSON and manual slug state in document memory; cmsEditor remains the dirty/submission owner and permalink remains the slug owner. The coordinator fetches same-origin server-rendered Blade, checks kind/owner, removes scripts, destroys the old Alpine tree and initializes the incoming tree after restoring its locale draft. Only the active form is submitted. Successful saves clear that locale, not other pending drafts. Native routing is the fallback; no general SPA router, new frontend framework or persistence service was added.
