# CMS completion audit — 2026-10-29

This checklist records the audit at the start of the critical follow-up. Prior dated evidence is in [Testing](testing.md); completion must include server and browser checks.

| Feature | Audit status | Verified implementation / gap |
| --- | --- | --- |
| Post/Page publication, scheduling, revisions, URL history and root Trash | Implemented and tested | Existing controllers/services plus the 106-test suite and CMS browser evidence. Preserve these workflows. |
| Linked locale content and locale metadata | Partially implemented | Existing normalized linked versions work, but initial root creation is fixed to English and switching is hidden in a disclosure. |
| Category/Tag CRUD, localized labels, search/sort/pagination/selection | Partially implemented | Existing tested shared term identity and label translations; filters and actual Trash/Restore are absent. |
| Category/Tag soft deletion, restore and permanent deletion from Trash | Missing | Current term deletion is permanent and cannot meet the requested restore workflow. |
| Featured-image persistence/public rendering/alt/decorative/caption | Implemented and tested | Existing Images references, public template and media regression tests. Preserve them. |
| Accessible featured-image picker with thumbnails/search/pagination/cancel | Missing | Only a native select and link to Images are present. |

## Completion approach

1. Add an immutable primary_locale to existing Post/Page roots, defaulting existing rows to en. New content may start in any configured locale without manufacturing an English translation; linked rows hold every other locale, including English. Preserve root IDs and current English URLs. Adapt shared publication, slug namespaces, revisions, media references and public resolution to that primary locale.
2. Add term SoftDeletes, retain translated labels and post assignments through Trash, filter by state/language/translation presence, and enforce permanent-delete relationships transactionally.
3. Extend the existing cover component and image routes with one native modal picker backed by bounded server pagination; keep native fallback and the existing private media library.
4. Verify routes, stored records, cross-locale isolation, language-switch dirty protection, taxonomy lifecycle, public featured images, keyboard/dialog behavior and existing regressions before marking complete.

## Completed implementation

| Feature | Completion status | Evidence |
| --- | --- | --- |
| Initial locale selection, linked versions, real states and isolated edits | Implemented and tested | CmsTest primary/linked persistence, namespaces, validation returns, RTL, public visibility and sitemap; CMS completion Chrome flow. |
| Category/Tag multilingual CRUD and filtered/paginated tables | Implemented and tested | CmsTest localization, pagination, language/missing filters, invalid selections and translation removal; Chrome category/tag save/remove and selection. |
| Category/Tag Trash/Restore/permanent deletion | Implemented and tested | Transactional relationship/translation retention and dependency tests; browser Trash/Restore plus confirmation/cancel/permanent deletion. |
| Featured-image picker and preserved use metadata | Implemented and tested | Private JSON search/pagination/authorization tests; Chrome search/page/cancel/confirm/reload/remove, focus/Escape and existing image regression. |
| Existing publication/editor/media behavior | Implemented and tested | Full isolated suite and existing CMS/images browser regressions; details and limits in [Testing](testing.md). |

The initial audit above is historical; this table records completion. No redesign, duplicate content identity, media library or frontend dependency was introduced.
