# Multilingual UX consolidation — 2026-10-30

Current request replaces previous visual recipes. Main observed source gap: language controls use full-page GET navigation, while cmsEditor only warns on unload; outgoing unsaved locale values cannot survive that navigation. Native browser form restoration may also race with persisted fields. Title, slug, rich document, SEO, manual override and dirty state require a shared per-locale volatile draft owner.

Priority: reproduce English → Turkish → English and Arabic → English in the actual rich editor, then fix state/lifecycle before cosmetic refinement. Keep one searchable Content Language control and a distinct translation-status overview. Shared versus localized settings must be explicit. Reference review and test evidence belong in Testing; no user study or universal UX acceptance is implied.
