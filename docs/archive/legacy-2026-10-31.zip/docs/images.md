# Shared images

Images is an administrator-only shared library, reused by English and translated Post/Page drafts. Upload JPEG, PNG or WebP up to 2 MiB, 4096px per side and 12 megapixels. Uploaded SVG, GIF, executables and remote URLs are excluded. PHP GD decodes pixels and re-encodes an immutable WebP (maximum 2048px) and 480px thumbnail with randomized paths on the private images disk. Originals and their metadata are not retained. Existing avatars remain separate.

Each asset has a shared name, intrinsic dimensions, byte size and uploader. Alt text and optional caption can be edited for all 30 catalog languages, including RTL fields. Missing translated metadata falls back to English for new selections; the UI indicates actual fallback and lists missing alt metadata. A file is never silently replaced: upload a new asset and explicitly change its references.

Cover and Tiptap selections store per-use alt, caption and decorative state. Non-decorative uses require meaningful non-empty alt text; decorative uses save an empty alt. Library defaults are copied into uses, so later library edits cannot silently rewrite existing content. The cover controls work without JavaScript; inline insertion is a rich-editor enhancement. A native editor dialog selects existing assets, previews the selected file, edits use-specific text, and restores trigger focus on close/Escape. Existing media survives an unchanged plain-text fallback; editing fallback text explicitly replaces rich formatting, including images.

image_usages records unique asset/owner/kind/locale/placement references. Root covers and localized covers also have restrictive image foreign keys. Content changes lock images and synchronize body/cover usage within the same transaction. Deleting a referenced asset is rejected server-side; the review screen links to its saved usages. Moving content to Trash retains references and language versions. Permanent deletion releases only its own references/versions/revisions. Retained revision checkpoints pin their body/cover assets with revision usages until pruned or permanently removed. Other content remains protected. Unsaved editor selections do not reserve an asset; a concurrent deletion is rejected when that draft tries to save.

Index thumbnails are paginated, lazy and intrinsically sized. Native selectors load names and selected-locale/English metadata; they do not preload full files, and selected previews load on demand. Library administration and original file routes remain administrator-only. A separate /media/{image} route serves an original only while it is referenced by actual published content or an inherited published cover; inactive locales, drafts, revisions and Trash cannot grant access alone. Both paths remain private/no-store. No CDN, editor upload bypass, public storage symlink, arbitrary HTML renderer, image cropping, EXIF orientation correction, malware scan or cloud storage is included. Failed file cleanup may leave an inaccessible orphan for operator review.

## Featured-image picker

The shared coverImage interaction uses a native modal dialog on Post/Page primary and linked forms. Select/Change opens the existing library; a private administrator-only JSON route provides bound search and 12 thumbnails per server page. Single-selection radio cards show name, filename and dimensions. Search, Previous/Next, Confirm, Cancel and Escape have keyboard controls. Cancel does not change the form; closing restores trigger focus. Confirming the unchanged asset preserves custom use text; a changed asset offers locale metadata and resets decorative state. Remove clears the explicit reference and saved use text; on linked versions this restores primary-cover inheritance. Native select/alt/decorative/caption controls remain the no-JavaScript fallback. Dialog transient controls do not affect dirty tracking or submit content. No asset duplication or remote media service is introduced.

Upload and metadata forms reuse the shared submitForm/submit-status pattern when no specialized owner exists. Private/library/usage rules are unchanged; dangerous unused-file confirmation uses the shared danger button variant.

## Cover metadata disclosure — 2026-10-30

The existing featured-image picker stays directly available. Native selection and per-use alt text, decorative state and caption sit in Image details. Enhancement collapses that disclosure when no image is selected and opens it for a selection or validation errors; without JavaScript it starts open. The existing coverImage owner controls this behavior without changing storage or inheritance.

## Library discovery and details — 2026-10-30

Screen brief: administrators visit to recognize an existing image, find its uses, or upload a reusable file. Image recognition and the upload action precede metadata editing. Observed friction was inconsistent thumbnail height, search-only discovery and identical empty/no-match messaging; a formal usability study was not performed.

The library now uses equal 4:3 contain previews, a linked image/name, intrinsic dimensions, file size and actual saved-reference counts. Two columns remain on mobile; wide screens use three. The total library count is distinct from filtered results. A native Upload image disclosure keeps the existing single-file upload and validation, opening for upload errors. No bulk upload is implied.

Search stays visible. Usage (all/in use/not in use), orientation and stable newest/oldest/name/size ordering are validated server-side inside native Filters & sorting. Active refinements stay expanded and pagination keeps query parameters. All stored files are WebP, so there is no redundant format filter. Empty-library guidance differs from no matching results, with a real filter-clear recovery link.

Image details remains a directly addressable page: preview and saved usage links precede a separate metadata area on mobile and sit alongside it on desktop. All 30 language options, missing-alt states, English fallback notices and RTL editing remain. The existing Post/Page picker and deletion guards are reused unchanged.
