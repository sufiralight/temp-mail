# Language management

Administrators manage 30 supported languages from Language. Only administrators may change the site default or edit homepage translations. English remains the initial default and immutable source. Existing administration, authentication and account interfaces remain English. The homepage and its visitor language controls are deferred; / continues to redirect to login. No personal-language settings or browser detection are included.

Eight initial source strings for the planned homepage are bundled in lang/en/homepage.php. Each supported language has matching starter translations; administrators can replace non-English values with plain text. Empty values restore the corresponding bundled translation. Saving validates the complete allowlisted key set and commits atomically, without modifying source files. Translations are escaped when displayed; stored markup never becomes executable HTML.

The config/languages.php catalog owns English/native labels and direction. Arabic, Hebrew, Persian and Urdu use RTL fields and previews; the management shell stays English/LTR. Native select controls and ordinary forms work without JavaScript. SiteLanguages::translations() resolves the saved default or an explicitly supported locale, merges bundled text and database overrides, and falls back to English if a source key is missing. This resolver is ready for the future homepage; saving a default does not translate unrelated screens. Bundled translations are starter copy, not certified native-language review.

Post/Page language drafts and image metadata are separate from fixed homepage strings. Their behavior is owned by [Content translations](content-translations.md) and [Images](images.md).

## Language table and availability

The management table replaces the former card grid. Server-side search matches English name, native name and locale; filters cover active status, direction and translation completeness. Name, locale and progress sort links preserve filters. Numbered pagination supports 10, 25, 50 or 100 rows, with invalid pages clamped to the last page. Editing and saving return to the same table context.

Selection covers eligible rows on the current page only and resets on navigation. Single and bulk activation apply immediately; deactivation requires a server-rendered review with cancel/confirm. Default languages cannot be selected or deactivated, inactive languages cannot become default, and at least one active language must remain. Changes validate the complete selection atomically under a singleton row lock. Deactivation never deletes translations or content. English remains immutable source even when another default allows English to be inactive.

Progress counts the eight source keys with non-empty text in the language's own bundled catalog or saved overrides, excluding English fallback. It is independent of the number of administrator customizations. Summary counts cover all 30 languages regardless of filters. SiteLanguages::activeCatalog() supplies active choices for future public controls; catalog() intentionally retains all languages for existing private content editing. There is still no public language selector.

## Category-based translation editor

The existing eight homepage keys remain in their files and override table. Category metadata in config/languages.php groups six existing keys under Homepage, faq_title under FAQ and footer_note under Footer. New source keys default to Homepage until explicitly categorized. Categories do not create new translation groups, mailbox functionality or database records. One shared x-translation-row renders each source/target pair; short labels use inputs, descriptions and multiline sources use textareas. English remains read-only and the PUT endpoint still requires every allowlisted key.

Saved statistics show total, translated, missing and customized keys independently. SiteLanguages::entries() supplies provenance and resolved text for both editor and language-table completeness: Bundled is genuine target resource text, Customized is a non-empty override, Fallback is missing target text resolved from English, and Missing has neither target nor source text. Missing counts include fallback; neither contributes to completion. Saved preview labels provenance and explicitly excludes unsaved edits and publication.

For this eight-key dataset, the translationEditor Alpine component filters by full key, source or target text, category and status without removing form controls. The missing-target filter includes fallback. Filtering preserves edits and hidden fields save through the same atomic endpoint. Without JavaScript, all labelled fields, categories, saved statistics, manual blank resets, preview and saves remain available; optional filter/reset controls are hidden.

Dirty tracking compares normalized line endings and trimmed effective target text against persisted values, including after validation errors. It counts and marks changed rows, adds native navigation protection only while dirty, suppresses it for submission, blocks repeated submissions and restores state on browser history return. Native warnings depend on browser user activation and are not guaranteed during mobile process termination. Text is never autosaved or put into browser storage. Clearing or Reset customization restores bundled text on save, with English fallback if target text is absent; it never deletes source keys.

Existing sources have no placeholders. When source text uses Laravel colon placeholders, validation preserves the exact case and number of occurrences; blank resets are exempt. Unsupported curly-brace interpolation is not introduced. Non-Latin text and meaningful textarea newlines are preserved. The shell stays English/LTR while source and target language/direction remain explicit.

The fixed public chrome catalog is separate from editable homepage strings and CMS records; its ownership and source/fallback rules are in [Internationalization](internationalization.md). Do not add these navigation/appearance keys to homepage completeness counts.
