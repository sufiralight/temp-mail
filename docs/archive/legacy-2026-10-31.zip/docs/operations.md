# Operations

Current implementation reviewed on 2026-10-29. Deployment remains pending. Runtime/package verification dates belong to [decisions](decisions.md), and test/audit results to [testing](testing.md).

## New local setup
Use PHP 8.5 with Laravel's required extensions and Node compatible with the locked Vite version. Install locked packages with composer install and npm ci --ignore-scripts, then npm run build. Copy .env.example only if .env is absent. Generate APP_KEY only for a new installation; never regenerate it on an installed instance. Do not run composer setup against installed state because that bootstrap script invokes key generation.

Run php artisan serve locally. Visit /install through an approved connection, choose the database, verify it, create the administrator, and complete setup. There is no install:key command or user-facing access key. Do not migrate a selected database before first verification: setup requires an empty database. Remote databases/users must already exist and permit migrations. SQLite uses the application's fixed private file.

MySQL/MariaDB require pdo_mysql, PostgreSQL requires pdo_pgsql, and SQLite requires pdo_sqlite. On 2026-10-28 this workstation had pdo_mysql/pdo_sqlite but lacked pdo_pgsql. Enable the required extension on the target server; do not treat connector support as a successful real-server integration test.

## Installer access
INSTALLATION_ALLOWED_IPS is a comma-separated list of exact peer addresses, defaulting to 127.0.0.1,::1. An empty list blocks setup. For direct remote setup, configure the intended administrator IP privately. Accepted hostnames are local names or the configured APP_URL host; Host never grants network permission.

Unfinished installation rejects Forwarded, X-Forwarded-For, X-Real-IP, X-Forwarded-Host, and X-Forwarded-Proto headers. Use a direct approved connection or restricted SSH tunnel. Do not expose it through a shared proxy or a proxy that strips all client metadata: a loopback proxy cannot be distinguished from a local user at the PHP layer. Keep setup behind an appropriate server/firewall rule. Deployment-specific proxy installation support is not implemented.

After successful database verification, an automatic 20-minute lease binds setup to that browser session. Another browser must wait for expiry. Completion rechecks the lease under the setup lock. This implementation assumes one server with persistent local storage; multi-server locking is not implemented.

## Persistent state and recovery
The private installation directory stores lease.json, encrypted database.enc, installed, setup.lock, and optionally application.sqlite. INSTALLATION_DIRECTORY can override its location; it must remain outside public/. Restrict permissions/ACLs to the PHP account and operator. Encrypted file sessions and file cache allow setup before database tables exist. Legacy access.hash files are ignored.

Back up the database, installation directory, original APP_KEY/.env, and private avatars together. The installed marker prevents repeated setup; .env is not locked or rewritten by the installer. Deleting .env is not a reinstall mechanism: losing APP_KEY prevents decryption of the connection configuration. Restore the original environment/key rather than generating a replacement or deleting installation state.

After interrupted setup, retry with the original connection in the owning session, or wait for lease expiry. Migrations resume and an existing committed administrator is preserved. Partial MySQL DDL failures may require operator repair after inspection and backup. Never automatically wipe data, delete installed/database.enc, or infer permission to reset from an interface request.

## Updates and photos
Existing installations need the additive migrations 2026_10_28_000002_add_avatar_path_to_users.php and 2026_10_28_000003_add_email_changes_and_avatar_presets.php. Both were applied successfully to the configured local database on 2026-10-28 without resetting users. Fresh installation includes them automatically. Use migrations only, never migrate:fresh, for existing data; inspect pending migrations before updates.

The avatars disk stores private files under storage/app/private/avatars. Grant PHP write access and back up files with their database references. No public storage link is needed. Align PHP upload_max_filesize/post_max_size with the application limits in [account](account.md), allowing multipart overhead. Cloud storage, image processing, and automatic orphan cleanup are not configured. SVG presets are bundled application markup, not uploaded files.

## Mail and production delivery
Configure a real supported mail transport and canonical HTTPS APP_URL before testing password resets or email changes. Log/array delivery is deliberately rejected for sensitive messages. Email-change notifications are synchronous; configure transport timeouts. No mail worker, automated delivery retry, or scheduled pending-request cleanup is configured. Exact failure/retry behavior is owned by [account](account.md). Tests use fake notifications; real SMTP delivery remains unverified.

Before production, define backups/recovery, asset delivery, permissions, secure cookies, proxy handling, HTTPS, APP_DEBUG=false and public/ as the web root. Keep source, .env, databases, storage, logs, audit artifacts and backups private. Avoid logging reset-token paths or query strings. Keep development servers and public/hot out of production. See [security](security.md) for headers/CSP and [testing](testing.md) for open verification gaps.

## Blog updates
The additive 2026_10_29_000001_create_blog_tables.php migration creates the blog draft, term and tag-association tables. It was applied to the configured local database on 2026-10-29 without resetting existing data. Fresh installers include it automatically. Rebuild frontend assets with the updated npm lockfile; the editor is loaded only on post and page forms and requires its separate built chunk to remain available. A failed editor download leaves a working plain-text form. Existing tables must not be recreated with migrate:fresh. Public blog hosting, publication URLs, editor image uploads and background publication jobs are not configured.

## Pages updates

The additive 2026_10_29_000002_create_pages_table.php migration adds private page drafts. Apply normal Laravel migrations without resetting existing data; fresh installation includes it automatically. Rebuild assets after the shared editor chunk is renamed to rich-text-editor. Migration verification is recorded in [testing](testing.md).

## Language updates

The additive 2026_10_29_000003_create_language_management_tables.php migration creates a singleton default-language row initialized to en and a unique locale/key override table. It was applied to the configured local database on 2026-10-29 without resetting data. Fresh installations include it normally. Back up these tables with application data; bundled catalogs are versioned under lang/. No translation provider credentials or queue are required.

## Shared images and content languages

The additive 2026_10_29_000004_add_shared_images_and_content_translations.php migration adds image metadata/usages, linked language drafts and nullable root-cover fields. It was applied to the configured local database without rebuilding existing records. Existing English content stays in its original tables. Back up the private images disk and its database references together. IMAGES_DIRECTORY can override storage/app/private/images for isolated test servers; do not point it into public/. No storage symlink, queue or external media credentials are needed.

Images upload requires PHP GD with WebP support. Local C:/php/php.ini was updated to enable the installed gd extension. Windows processes with the previous extension layout shared an incompatible OPcache namespace; the local opcache.cache_id is now temp-mail-gd to isolate new GD-enabled processes without disabling opcode caching. The documented PHP directive is [opcache.cache_id](https://www.php.net/manual/en/opcache.configuration.php#ini.opcache.cache-id), reviewed on 2026-10-29. Restart existing PHP workers after changing extensions.

Image upload uses the existing 2 MiB PHP limit; post_max_size=8M and memory_limit=128M were retained locally. A proposed global upload-limit increase was rejected by automatic approval review, so the application/UI/tests use 2 MiB and no limit increase was made. Source dimensions are separately bounded before decoding. Operators must provision writable private storage and GD/WebP on other hosts. Avatar validation and storage are unchanged.

The additive 2026_10_29_000005_add_language_activation_state.php migration adds nullable JSON inactive_locales to the existing singleton language_settings row. Null preserves all 30 languages as active. It was applied locally without resets or translation changes. Back up this state with the database; no new environment variables or packages are required.

## CMS lifecycle and scheduled publication

The additive 2026_10_29_000006_expand_content_lifecycle.php migration adds publication/SEO/version fields, nullable root soft deletion, bounded revision snapshots, historical URL reservations and term-label translations. Existing posts/pages/locale records remain Draft and keep their IDs, authors and content. Composite publication/update indexes support list/due queries. The additive 2026_10_29_000007_create_content_namespace_locks.php migration serializes live/historical slug checks per kind/locale; lock rows are created lazily and contain no content. Both migrations were applied on the configured local database without resetting records. Back up database and private images together, including retained revisions and usage pins.

Publication instants are stored and read explicitly in UTC regardless of the application timezone. The native form labels and previews say UTC; operators/users must convert local wall time before entering it. Explicit UTC avoids ambiguous/nonexistent DST wall times. The scheduler entry invokes php artisan cms:publish-due every minute with overlap protection. It is idempotent, skips Trash, and holds scheduled translations until their root is published. Public routes independently reject not-due schedules; a delayed worker never exposes content prematurely.

For continuous publication, configure the deployment's normal Laravel scheduler to run php artisan schedule:run each minute, or use php artisan schedule:work during a local session. The task registered and tested the execution path but did not install a production cron, daemon, service or background worker. php artisan schedule:list verifies the registration; php artisan cms:publish-due can be run manually against the intended installed application. Do not run these commands against an unintended database. See Laravel's [scheduler deployment instructions](https://laravel.com/docs/13.x/scheduling#running-the-scheduler), reviewed 2026-10-29.

Old article paths resolve through content identity without stored redirect chains. Do not manually remove reservations to reuse another article's published URL. Trash keeps image references; unused assets can remain protected by up to 20 revisions per locale until those revisions are pruned or their owner permanently deleted. No automatic empty-trash job, revision-on-keystroke autosave, public draft-sharing link or deployment is added.

## CMS completion migration

The additive 2026_10_29_000008_complete_cms_locales_and_term_trash.php migration was applied on the configured local database on 2026-10-29 without resets. It defaults existing Post/Page/BlogTerm primary_locale to en, scopes primary slug indexes by locale and adds nullable term deleted_at. Existing IDs/content/relationships remain in place. Back up the database and private images before applying normal migrations elsewhere. Rollback refuses non-English primary content, cross-locale duplicate slugs or remaining term Trash rather than silently changing their meaning. No new environment variables or dependencies are required.
