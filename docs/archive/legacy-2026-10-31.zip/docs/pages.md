# Pages

Pages remains a separate administrator navigation destination. The CMS expansion approved on 2026-10-29 adds the same proven table, lifecycle, Trash/Restore, revision, permalink, SEO and preview patterns as [Blog](blog.md), without blog categories or tags. Existing page IDs, authors, English content, slugs and media relationships are retained.

PageController owns page-specific persistence; ContentTable, ContentLifecycle, shared publication/permalink/SEO components and the existing rich editor supply common behavior. Each page has title, slug, constrained content, excerpt, optional cover and locale-specific SEO fields. Language versions remain linked through content_translations. The visible pre-creation selector supports any catalog primary locale; the same shared Translations section and image picker serve Pages. New optional parent/order/template fields are not included.

Pages publish at /{locale}/pages/{slug}; visibility, translation coverage and historical URLs follow [Content translations](content-translations.md). Every management, preview and revision endpoint requires administrator authorization. Public rendering never exposes a draft, future schedule or trashed root. Native forms, blank resets and plain-text fallback remain usable without JavaScript. Operational scheduling and migration requirements belong to [Operations](operations.md), evidence to [Testing](testing.md).

## Shared writing layout — 2026-10-30

Pages follows the collection and editor presentation described in [Blog](blog.md), retaining its own routes, lifecycle and prepared data. No new page capabilities or public homepage were introduced.

Pages uses the same locale-isolated volatile editor navigation as Posts; see [Content translations](content-translations.md). Native forms remain usable without enhancement.
