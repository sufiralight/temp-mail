# CRITICAL FOLLOW-UP — COMPLETE MISSING MULTILINGUAL CMS FEATURES

You previously improved the Temp Mail SaaS Create Post interface, but essential multilingual CMS functionality is still missing or not visibly accessible.

Do not redesign the interface again.

The current Laravel 13 Blade + Tailwind + Alpine.js architecture and visual design must remain intact.

## PRIMARY GOAL

Complete the missing functionality in:

1. Posts
2. Categories
3. Tags
4. Featured Images
5. Multilingual content management
6. Trash and Restore workflows

This is a functionality-completion task, not a cosmetic redesign.

## 1. FIX POST LANGUAGE SELECTION

The Create Post screen currently has no visible language selector.

Add a clear **Content Language** selector near the top of the editor.

Support all 30 configured languages.

Requirements:

- Select the language before creating a post.
- Show native language names.
- Display the selected locale.
- Apply correct RTL/LTR direction to content fields.
- Automatically generate locale-specific slugs.
- Allow manual slug editing.
- Save content under the correct locale.
- Preserve the selected locale after validation errors.

After the initial post is saved, provide a **Translations** management section.

It must show all 30 languages and their actual states:

- Published
- Draft
- Missing

Allow users to:

- Add a translation
- Edit a translation
- Save a translation draft
- Publish a translation
- Unpublish a translation
- Preview a translation

All translations must belong to one logical post identity.

Do not create unrelated duplicate posts.

Do not overwrite another language's content when switching languages.

Protect unsaved edits when switching language tabs.

## 2. FIX MULTILINGUAL CATEGORIES

The Categories management page must support complete CRUD and localization.

Required features:

- Create category
- Edit category
- Search categories
- Filter categories
- Sort categories
- Numbered pagination
- Individual checkbox selection
- Select all on current page
- Bulk actions
- Move to Trash
- Restore from Trash
- Permanently delete from Trash

### Category translations

Each category should have one shared identity and language-specific fields.

For each locale:

- Category name
- Slug
- Description, if supported

Provide a language selector or translation management interface.

Show missing translations clearly.

Do not create 30 unrelated categories for one conceptual category.

Category deletion must not automatically delete associated posts.

Define and enforce safe category relationship behavior.

## 3. FIX MULTILINGUAL TAGS

Implement equivalent functionality for Tags.

Required:

- Create tag
- Edit tag
- Delete to Trash
- Restore
- Permanently delete
- Search
- Filter
- Sorting
- Pagination
- Individual selection
- Select all
- Bulk actions

### Tag translations

Support localized:

- Tag name
- Slug
- Description, if applicable

Use one shared tag identity with multiple localized representations.

Do not create duplicate independent tags for translations.

Do not delete posts when tags are removed.

## 4. IMPLEMENT WORKING FEATURED IMAGE SELECTION

The existing project already has an Images management module.

The Create/Edit Post screen must be able to choose a featured image directly from that media library.

Do not create a second independent media system.

### Required UI

In the Post Settings sidebar, implement:

**Featured image**

- Select image
- Change image
- Remove image
- Thumbnail preview
- Image filename
- Alt text
- Decorative image option
- Optional caption

### Media picker

Clicking Select image must open an accessible media selection interface.

Support:

- Existing uploaded images
- Image thumbnails
- Search
- Pagination or lazy loading
- Single-image selection
- Confirm selection
- Cancel selection

If the existing Images module supports uploads, optionally allow uploading from the picker.

Reuse the existing upload validation and storage mechanisms.

### Persistence

Store the selected media reference with the post.

On edit, show the previously selected image.

Ensure the featured image appears in the public post template when published.

Preserve image metadata.

Do not delete the image file when a post is deleted or moved to Trash.

Prevent selecting unauthorized or nonexistent media records.

## 5. IMPLEMENT REAL TRASH AND RESTORE

Posts, Categories, and Tags need functional Trash management.

Implement:

- Soft deletion
- Trash listing
- Individual restore
- Bulk restore
- Permanent deletion
- Confirmation for permanent deletion

Preserve translations during soft deletion.

Handle shared relationships safely.

Do not destroy content when restoring an item.

Use Laravel SoftDeletes where appropriate.

Inspect the existing schema before changing anything.

## 6. REUSE THE LANGUAGE DATA TABLE STANDARD

The existing Language management page already uses:

- Search
- Filters
- Sorting
- Pagination
- Row selection
- Bulk actions
- Status indicators

Reuse these patterns for:

- Posts
- Categories
- Tags

Do not duplicate large blocks of UI code unnecessarily.

Ensure every visible control has working backend behavior.

Do not create decorative buttons without functionality.

## 7. SLUG AND ROUTING RULES

For Posts, Categories, and Tags:

- Generate slugs automatically from localized titles/names.
- Support manual overrides.
- Never overwrite manually edited slugs.
- Validate uniqueness in the correct locale and route namespace.
- Prevent invalid slugs.
- Handle Unicode safely.
- Avoid silent changes to published URLs.

For published content, preserve existing URLs or implement safe redirects when necessary.

Use the project's actual route definitions.

Do not hardcode assumed URL structures.

## 8. DATA MODEL AND RELATIONSHIPS

Audit the existing models and migrations first.

The desired conceptual relationships are:

- Post has many PostTranslations.
- Category has many CategoryTranslations.
- Tag has many TagTranslations.
- Post belongs to one or more categories according to the existing business rules.
- Post belongs to many tags.
- Post optionally references a featured image.
- All translations reference their shared parent entity.

Adapt this model to existing data rather than blindly replacing tables.

Do not introduce destructive migrations.

Preserve all existing content and relationships.

## 9. UX REQUIREMENTS

Preserve the existing:

- Dark/light themes
- Mint-green accent color
- Sidebar
- Typography
- Card styling
- Rich-text editor
- Collapsible settings sections

Make language selection obvious.

Make translation statuses understandable.

Make image selection easy.

Keep the Create Post screen focused.

Do not expose all 30 translation forms simultaneously.

Use progressive disclosure and accessible navigation.

## 10. REQUIRED TESTS

Add and run tests verifying:

- Post creation in a selected language
- Correct locale persistence
- Editing one translation without affecting another
- Category creation and localization
- Tag creation and localization
- Automatic slug generation
- Manual slug preservation
- Featured image selection and persistence
- Featured image rendering
- Soft deletion
- Restoration
- Permanent deletion
- Pagination
- Search and filtering
- Bulk actions
- Authorization
- Invalid IDs and locales
- RTL field rendering

## 11. IMPLEMENTATION ORDER

First audit what was actually implemented in the previous iteration.

Create a feature checklist with three statuses:

- Implemented and tested
- Partially implemented
- Missing

Then complete the work in this order:

1. Post language selection and translation persistence
2. Category multilingual CRUD
3. Tag multilingual CRUD
4. Featured image media picker
5. Trash and Restore
6. Data table consistency
7. Tests and regression fixes

Do not mark a feature complete merely because a UI control exists.

Verify the controller, route, persistence, authorization, and actual browser behavior.

## STRICT RULES

- Do not rebuild the project.
- Do not change the current visual design.
- Do not introduce React, Vue, Livewire, or Inertia.
- Do not install unnecessary packages.
- Do not remove existing content.
- Do not break current routes.
- Do not create duplicate translation records.
- Do not delete shared media accidentally.
- Do not create nonfunctional UI controls.
- Do not claim tests passed without executing them.

## FINAL EXPECTATION

A fully functional multilingual CMS for the 30-language Temp Mail SaaS platform.

Every module must support the appropriate management operations.

The Create Post editor must have visible language selection, working translation management, automatic localized slugs, and real featured-image selection from the existing Images library.

**START NOW: Audit the current implementation, identify missing features, and complete them incrementally. Prioritize working functionality over further visual redesign.**