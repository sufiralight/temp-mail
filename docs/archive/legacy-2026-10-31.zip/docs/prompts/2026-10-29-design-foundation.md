# ROLE: Principal SaaS Product Architect, Staff Laravel Engineer, Design Systems Lead & Senior UX/UI Designer

## MISSION

Establish and enforce ONE permanent, project-wide design system, UX architecture, and engineering standard for my entire Temp Mail SaaS application.

I do not want to repeatedly request UX/UI improvements for individual pages.

Every existing and future page, feature, component, and administration module must follow the same documented standards automatically.

The goal is to make premium UX/UI a permanent architectural property of this project, not an optional improvement.

## PROJECT CONTEXT

Application: Temp Mail SaaS

Technology:
- Laravel 13
- Laravel Blade Components
- Tailwind CSS
- Alpine.js
- Vite
- Server-side rendering

Internationalization:
- 30 supported languages
- RTL/LTR support
- Multilingual public content
- Multilingual CMS
- International SEO

Existing modules include:
- Dashboard
- Blog Posts
- Categories
- Tags
- Pages
- Languages
- Edit Translations
- Images
- My Account
- Public Temp Mail functionality

The project already contains agent instruction files and documentation under agents/docs-related directories.

**IMPORTANT: Inspect the actual repository structure before making any assumptions.**

## 1. DISCOVER AND RESPECT EXISTING PROJECT RULES

First inspect the project root and relevant directories.

Find existing instruction and documentation files, including where present:

- AGENTS.md
- Nested AGENTS.md files
- CLAUDE.md
- .cursor/rules/
- .github/instructions/
- docs/
- agents/
- Existing architecture documentation
- Existing UI/component documentation
- Existing coding standards

Read and understand them before modifying code.

Do not overwrite existing instructions blindly.

Identify contradictions, duplication, obsolete rules, and missing standards.

Preserve project-specific decisions and existing working conventions.

If multiple agent systems exist, maintain one canonical set of project rules with thin tool-specific references where appropriate.

Do not assume every AI coding tool reads the same instruction files automatically.

## 2. CREATE A PERMANENT DESIGN SYSTEM

Audit the current UI across the entire project.

Establish a canonical design system inspired by the quality principles of:

- Stripe: precision, consistency, information hierarchy
- Vercel: minimalism, restrained visual language, interaction quality
- Vite: modern developer-product identity

Do not copy these brands.

Preserve and refine the Temp Mail SaaS mint-green identity.

Document the design system in the existing documentation structure.

Include:

### Color tokens
- Background
- Surface
- Elevated surface
- Borders
- Primary text
- Secondary text
- Muted text
- Brand accent
- Success
- Warning
- Error
- Focus

### Typography
- Font families
- Font sizes
- Line heights
- Font weights
- Heading hierarchy
- Labels
- Helper text
- Table typography
- Multilingual font handling

### Layout
- App shell
- Sidebar width
- Header height
- Content maximum width
- Page padding
- Grid rules
- Responsive breakpoints
- Section spacing

### Components
- Buttons
- Inputs
- Selects
- Checkboxes
- Radio controls
- Textareas
- Cards
- Dialogs
- Dropdowns
- Tables
- Pagination
- Badges
- Alerts
- Toasts
- Empty states
- Loading states
- Skeletons
- Page headers
- Tabs
- Accordions
- Tooltips

Define variants and states consistently.

Do not allow arbitrary page-specific styling when an existing token or component can solve the problem.

## 3. MAKE THE DESIGN SYSTEM REAL, NOT JUST DOCUMENTATION

Documentation alone is insufficient.

Implement or refine shared Tailwind tokens, Blade components, layouts, and Alpine interaction patterns.

All common UI elements must use the shared system.

Avoid duplicated CSS and inconsistent component implementations.

Prefer semantic design tokens rather than scattered hardcoded color values.

Ensure dark and light themes use the same semantic token structure.

Keep component APIs small, explicit, and maintainable.

Do not build an unnecessarily complex component framework.

## 4. ESTABLISH PROJECT-WIDE UX PATTERNS

Document mandatory interaction standards for the entire application.

### Data tables

Whenever a module manages collections of records, use the shared data-table pattern where appropriate.

Standard capabilities:

- Search
- Filtering
- Sorting
- Numbered pagination
- Configurable page size
- Individual selection
- Select all on current page
- Contextual bulk actions
- Row actions
- Empty states
- Loading states
- Error feedback

For modules supporting deletion, provide safe Trash/Restore workflows.

Do not add destructive operations to modules where they do not make sense.

### Forms

All forms must consistently support:

- Labels
- Help text
- Validation feedback
- Disabled states
- Loading/submitting states
- Success feedback
- Unsaved changes protection when appropriate
- Accessible keyboard behavior

### Editors

Content editors must follow shared patterns for:

- Save
- Draft
- Publish
- Preview
- Slug editing
- SEO metadata
- Language selection
- Media selection
- Unsaved changes

### Destructive actions

Use consistent confirmation and recovery behavior.

Prefer reversible operations where appropriate.

### Navigation

Use one coherent pattern for:

- Sidebar
- Breadcrumbs
- Page headers
- Tabs
- Subnavigation
- Mobile navigation

## 5. GLOBAL PREMIUM UX QUALITY BAR

Every page must feel like part of the same premium SaaS product.

Require:

- Precise alignment
- Consistent spacing
- Strong information hierarchy
- Clear primary actions
- Appropriate information density
- Purposeful progressive disclosure
- Accessible interactions
- Responsive layouts
- Refined hover/focus/selected states
- Minimal visual noise
- Consistent feedback

Avoid:

- Generic admin-template aesthetics
- Excessive cards
- Oversized empty sections
- Random gradients
- Inconsistent button sizes
- Arbitrary border radii
- Different table designs between modules
- Different form styles between modules
- Decorative nonfunctional controls
- Unnecessary animations

Premium quality must come from clarity, consistency, and attention to detail.

## 6. DEFINE A SHARED ADMIN APPLICATION SHELL

All administration pages must use one consistent shell.

Standardize:

- Header
- Sidebar
- Main content area
- Page heading
- Breadcrumbs where useful
- Action placement
- Responsive navigation
- Dark/light theme behavior

Do not allow individual modules to recreate their own shell.

## 7. DEFINE PUBLIC WEBSITE DESIGN RULES

The public Temp Mail website should share the same brand identity but not necessarily the same administration layout.

Create separate public-facing layout patterns for:

- Homepage
- Temporary mailbox
- Inbox
- Email message view
- Blog
- Blog post
- Categories
- Tags
- Informational pages
- Error pages

Maintain common tokens, typography, accessibility, and brand identity.

Do not force admin-style data tables or navigation onto public pages.

## 8. ENFORCE 30-LANGUAGE UX

Document permanent internationalization rules.

All public-facing components must support:

- 30 locales
- RTL/LTR layouts
- Locale-aware URLs
- Unicode content
- Long translations
- Accessible language switching
- Localized metadata
- Correct translation fallback
- Consistent locale-specific formatting

English is the canonical source for fixed UI translations.

Dynamic CMS translations must remain separate from fixed interface translations.

Do not treat English fallback as completed localization.

Do not hardcode public-facing strings in Blade templates.

## 9. DEFINE CMS-WIDE STANDARDS

Posts, Categories, Tags, and Pages must share consistent UX patterns where applicable.

Posts and Pages:

- Multilingual content editing
- Automatic localized slugs
- Draft/Publish workflows
- SEO
- Preview
- Media selection
- Trash/Restore

Categories and Tags:

- Multilingual labels
- Localized slugs
- CRUD
- Search
- Pagination
- Bulk actions
- Safe deletion

Use shared components without mixing business rules.

## 10. ACCESSIBILITY AND PERFORMANCE

Target WCAG 2.2 AA.

Enforce:

- Semantic HTML
- Keyboard navigation
- Visible focus
- Correct ARIA usage
- Contrast requirements
- Accessible dialogs
- Accessible data tables
- Reduced-motion support
- Responsive touch targets
- RTL compatibility

Performance requirements:

- Server-rendered HTML by default
- Minimal Alpine.js
- No unnecessary frontend dependencies
- No excessive JavaScript bundles
- No avoidable layout shifts
- Efficient database queries

## 11. CREATE AN AI AGENT DEVELOPMENT CONTRACT

Update the existing agent instructions so that every future coding task must:

1. Read the relevant project rules and design documentation.
2. Inspect existing components before creating new ones.
3. Reuse the canonical design system.
4. Follow established UX patterns.
5. Preserve existing business logic.
6. Respect multilingual requirements.
7. Implement accessible interaction states.
8. Test relevant functionality.
9. Verify dark/light themes.
10. Verify responsive layouts.
11. Avoid introducing inconsistent styles.
12. Update documentation when shared patterns change.

Add an explicit rule:

**A feature is not complete merely because its backend works or its page renders. It must also comply with the project's design system, interaction standards, accessibility requirements, and responsive behavior.**

## 12. AUTOMATED CONSISTENCY CHECKS

Where practical, implement automated checks to detect:

- Hardcoded colors outside approved tokens
- Duplicate shared UI components
- Inconsistent button variants
- Missing form labels
- Missing translation keys
- Unsafe or inaccessible controls
- Broken Blade views
- CSS build failures
- Relevant UI regressions

Use existing tooling wherever possible.

Do not introduce heavy tooling without clear value.

If visual regression testing infrastructure exists, reuse it.

If not, propose a lightweight approach before adding dependencies.

## 13. PROJECT-WIDE IMPLEMENTATION

After documenting the standards, apply them across the application.

Recommended order:

1. Shared design tokens
2. Shared Blade components
3. Admin shell
4. Language management
5. Translation editor
6. Posts
7. Categories
8. Tags
9. Pages
10. Images
11. My Account
12. Dashboard
13. Public Temp Mail pages

Preserve functionality at every stage.

Do not perform an uncontrolled mass rewrite.

Use incremental, testable changes.

## 14. DOCUMENTATION DELIVERABLES

Reuse or update existing documentation files.

Where missing, create appropriate canonical documentation for:

- Design system
- UX patterns
- Component usage
- Architecture
- Internationalization
- Accessibility
- Quality checklist

Update AGENTS.md or the existing equivalent entrypoint to reference these documents.

Avoid duplicating full documentation across multiple agent files.

Ensure instructions are discoverable by the AI coding tools used in the repository.

## 15. DEFINITION OF DONE

A page or feature is complete only when:

- It uses the canonical design tokens.
- It reuses shared components where appropriate.
- It follows established UX patterns.
- Its primary and secondary actions are clear.
- All visible controls work.
- Validation and feedback are consistent.
- Keyboard accessibility is verified.
- Responsive behavior is verified.
- Dark/light themes are verified.
- RTL/LTR behavior is verified where relevant.
- Existing functionality remains intact.
- Relevant tests and build checks pass.

## STRICT RULES

- Do not rebuild the project.
- Do not introduce React, Vue, Livewire, or Inertia.
- Do not overwrite existing agent documentation blindly.
- Do not duplicate design rules across files.
- Do not replace working business logic for cosmetic reasons.
- Do not introduce unnecessary dependencies.
- Do not create inconsistent page-specific components.
- Do not invent backend functionality.
- Do not remove existing features.
- Do not perform destructive migrations.
- Do not claim tests passed without running them.
- Do not sacrifice accessibility or performance.

## FINAL GOAL

Transform Temp Mail SaaS into one coherent, premium, multilingual product.

Every administration module and public-facing page must feel like it belongs to the same product family.

The quality standard should reflect the precision of Stripe and the restraint of Vercel while retaining the distinctive Temp Mail SaaS brand.

**Most importantly: future AI coding sessions must automatically follow the same project-wide UX/UI and architecture standards without requiring me to repeat these instructions.**

## START NOW

1. Inspect the entire repository.
2. Read existing agents and docs.
3. Audit current UI and architecture.
4. Identify conflicting or missing standards.
5. Establish canonical design and UX documentation.
6. Update agent instructions.
7. Implement shared tokens and components.
8. Apply the system incrementally across the project.
9. Run tests and report results.

Do not stop after producing documentation. Implement the shared design foundation and begin applying it to real screens.