# ROLE: Senior Laravel 13 Architect & Premium SaaS Admin UX/UI Engineer

## PROJECT CONTEXT

I am developing a multilingual **Temp Mail SaaS** platform supporting 30 languages.

Current technology stack:

- Laravel 13
- Laravel Blade Components
- Tailwind CSS
- Alpine.js
- Vite
- Server-side rendering

The existing admin interface uses a clean, light-colored design with a subtle green accent, sidebar navigation, rounded panels, and minimal typography.

**Preserve this visual identity. Do not redesign the entire application or introduce a new design system.**

## PRIMARY TASK

Modernize the existing `/languages` administration page.

The current interface displays all 30 languages as individual cards in a three-column grid.

This creates excessive scrolling, repeated information, and inefficient administration.

Replace the language-card grid with a professional, compact, accessible, server-driven **Data Table**.

The result should feel like a mature SaaS administration interface.

## 1. PAGE STRUCTURE

Organize the Language page into:

### Page Header
- Title: Languages
- Short description
- Language settings action

### Summary
Display compact information:

- Total languages
- Active languages
- Inactive languages
- Default language

Use real backend data, never hardcoded statistics.

### Language Management Table
Create one clean management table with search, filtering, sorting, selection, and actions.

### Default Language Settings
Keep the existing default-language functionality.

Place it in a compact settings panel or accessible settings section instead of a large, permanently expanded card.

Preserve the current update endpoint and validation.

## 2. DATA TABLE COLUMNS

The table should include:

1. Selection checkbox
2. Language name and native name
3. Locale code
4. Text direction (LTR/RTL)
5. Translation progress
6. Active/Inactive status
7. Default language indicator
8. Row actions

Keep the table visually minimal and easy to scan.

Use badges only for meaningful statuses.

## 3. SEARCH, FILTERS, AND SORTING

Implement:

- Search by language name
- Search by native language name
- Search by locale code
- Filter by Active/Inactive
- Filter by RTL/LTR
- Filter by translation completeness
- Sort by language name
- Sort by locale code
- Sort by translation progress
- Clear all filters

Use Laravel query parameters and server-side filtering.

Preserve search, filters, and sorting across pagination and actions.

## 4. PAGINATION

Implement Laravel server-side pagination.

Requirements:

- Numbered pagination
- Previous and Next buttons
- Current page indicator
- Total record count
- Showing X–Y of Z records
- Page size selector: 10, 25, 50, 100
- Preserve filters and sorting
- Accessible keyboard navigation

Do not load the entire dataset into Alpine.js merely to paginate it.

## 5. ROW SELECTION

Implement professional checkbox selection.

Requirements:

- Select individual languages
- Select all eligible rows on the current page
- Deselect individual rows
- Clear selection
- Display the selected count
- Show a contextual bulk-action toolbar when rows are selected

Optionally provide an explicit "Select all matching results" action across filtered pages.

Never silently apply actions to hidden or unselected records.

## 6. BULK ACTIONS

Support:

- Bulk Activate
- Bulk Deactivate

Requirements:

- Show the number of affected languages.
- Require confirmation for bulk deactivation.
- Display clear success/error feedback.
- Validate permissions server-side.
- Protect against invalid or manipulated locale codes.
- Handle partial failures predictably.
- Avoid duplicate submissions.

Do not implement bulk delete unless explicitly requested.

## 7. INDIVIDUAL LANGUAGE ACTIONS

Each language row should support:

- Edit translations
- Activate
- Deactivate

Use a compact action menu where appropriate.

Keep existing translation editor routes and functionality intact.

## 8. LANGUAGE BUSINESS RULES

The application supports:

en, ar, bn, zh, cs, nl, fr, de, el, he, hi, id, it, ja, ko, ms, fa, pl, pt, ro, ru, es, sw, sv, ta, th, tr, uk, ur, vi.

Important:

- English is the fixed canonical translation source.
- The site default language may differ from English.
- Never deactivate the configured default language without first assigning another default.
- Never allow all languages to become inactive.
- Never delete translations when deactivating a language.
- Inactive languages must not appear in the public language selector.
- Existing translation records must remain intact.
- Preserve the current eight homepage translation keys.
- Do not confuse customized translation count with actual translation completeness.

If the existing database does not support Active/Inactive status, inspect the architecture and propose the smallest safe schema change before implementing it.

## 9. VISUAL DESIGN REQUIREMENTS

Preserve the existing Temp Mail SaaS visual style:

- Light neutral background
- White surfaces
- Subtle borders
- Muted secondary text
- Dark green primary actions
- Consistent rounded corners
- Existing typography
- Existing sidebar

Improve:

- Visual hierarchy
- Information density
- Table readability
- Spacing consistency
- Alignment
- Button hierarchy
- Responsive behavior

Avoid:

- Excessive cards
- Large empty spaces
- Heavy shadows
- Unnecessary gradients
- Oversized buttons
- Decorative animations
- Generic dashboard templates

The interface should look modern through clarity and consistency, not decoration.

## 10. REUSABLE COMPONENT ARCHITECTURE

Inspect existing Blade components before creating new ones.

Consider reusable components for:

- Data table container
- Table toolbar
- Search input
- Filter controls
- Sortable column header
- Pagination
- Selection toolbar
- Status badge
- Row action menu
- Confirmation dialog
- Empty state

Create components only when they provide meaningful reuse.

The same data-table foundation should eventually support:

- Blog posts
- Categories
- Tags
- Pages
- Images
- Other administration modules

Do not modify those modules in this task.

Do not overengineer the component system.

## 11. ALPINE.JS RESPONSIBILITIES

Use Alpine.js only for lightweight interactions:

- Checkbox selection
- Bulk toolbar visibility
- Dropdown menus
- Confirmation dialogs
- Expandable settings

Keep filtering, sorting, pagination, authorization, and data updates on the Laravel server.

Do not introduce React, Vue, Livewire, Inertia, or heavy data-table packages.

## 12. ACCESSIBILITY

Target WCAG 2.2 AA.

Ensure:

- Semantic table markup
- Accessible checkbox labels
- Correct table headers
- Keyboard-operable action menus
- Visible focus states
- Screen-reader-friendly feedback
- Accessible confirmation dialogs
- Proper mobile behavior
- RTL-compatible layout utilities

## 13. BACKEND QUALITY

Follow Laravel best practices.

Use:

- Existing controllers and services where appropriate
- Form Request validation
- Authorization policies or gates
- Database transactions when necessary
- Efficient queries
- Native Laravel pagination
- CSRF protection
- Named routes
- Existing conventions

Avoid N+1 queries, duplicated logic, unnecessary migrations, and unnecessary dependencies.

## 14. TESTING

Add or update focused tests for:

- Search
- Filtering
- Sorting
- Pagination
- Individual activation/deactivation
- Bulk activation/deactivation
- Default language protection
- Authorization
- Invalid locale submissions
- Empty result states
- Preservation of translation data

Run relevant tests and report failures accurately.

## 15. IMPLEMENTATION WORKFLOW

Follow these steps:

1. Inspect the current `/languages` implementation.
2. Identify existing reusable Blade components.
3. Inspect language routes, controllers, models, and translation storage.
4. Identify missing functionality.
5. Prepare a concise implementation plan.
6. Implement the improved interface incrementally.
7. Add backend support only where required.
8. Add focused tests.
9. Run relevant checks.
10. Summarize modified files and any remaining limitations.

## STRICT RULES

- Do not rebuild the project.
- Do not change the existing visual identity.
- Do not modify unrelated modules.
- Do not remove existing functionality.
- Do not break translation editing.
- Do not introduce unnecessary packages.
- Do not invent backend capabilities.
- Do not use fake production statistics.
- Do not perform unnecessary database migrations.
- Do not introduce a frontend SPA framework.
- Do not replace working code without a reason.

## FINAL EXPECTATION

Deliver a clean, compact, fast, accessible, professional Language administration interface with:

**Search + Filters + Sorting + Pagination + Individual Selection + Select All + Bulk Actions + Active/Inactive Management + Translation Editing.**

The result must integrate naturally into the existing Temp Mail SaaS admin panel.

**START BY AUDITING THE EXISTING PROJECT. Then implement the smallest safe set of changes needed to achieve this result.**