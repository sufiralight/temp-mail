# ROLE: Principal Laravel Architect, Senior CMS Engineer & SaaS UX/UI Designer

## PROJECT

I am developing a multilingual **Temp Mail SaaS** platform with an integrated content management system.

### Existing technology stack

- Laravel 13
- Laravel Blade Components
- Tailwind CSS
- Alpine.js
- Vite
- Server-side rendering
- Existing rich-text editor with slash commands

### Existing administration navigation

- Dashboard
- Blog
  - Posts
  - Categories
  - Tags
- Pages
- Language
- Images
- My account

The Language administration page already uses a professional data-table interface with filtering, pagination, selection, and bulk actions.

The Posts and Create Post pages currently use a clean dark/light interface with mint-green accents, compact typography, rounded panels, and sidebar navigation.

**Preserve the existing visual identity. Do not rebuild the application or introduce a different frontend framework.**

---

# PRIMARY OBJECTIVE

Transform the existing Posts management and Create/Edit Post experience into a professional, scalable, multilingual CMS inspired by the usability of WordPress.

The result must be suitable for a 30-language Temp Mail SaaS application.

Use WordPress as a UX reference, not as an architectural dependency.

Do not blindly copy WordPress or introduce unnecessary complexity.

**Start by auditing the existing project. Preserve working features and implement missing functionality incrementally.**

---

# 1. POSTS MANAGEMENT — PROFESSIONAL DATA TABLE

Replace the basic Posts listing with a reusable Laravel-powered data table.

The interface must remain visually consistent with the existing Language management table.

### Table columns

- Selection checkbox
- Post title
- Primary language
- Translation coverage
- Category
- Tags
- Publication status
- Author, if supported
- Last updated
- Actions

Use compact, readable rows.

The post title should link to the editor.

### Status navigation

Provide:

- All
- Published
- Drafts
- Scheduled
- Trash

Display real record counts.

Do not hardcode statistics.

### Search

Support searching by:

- Post title
- Slug
- Content, where efficient
- Translation title
- Category

Search must work correctly with multilingual Unicode content.

### Filters

Support:

- Language
- Status
- Category
- Tag
- Publication date
- Translation availability

### Sorting

Support:

- Title
- Creation date
- Updated date
- Publication date
- Status

Preserve filters and sorting across pagination.

---

# 2. PAGINATION

Implement native Laravel server-side pagination.

Requirements:

- Numbered pages
- Previous and Next
- Current page indicator
- Total records
- Showing X–Y of Z
- Rows per page: 10, 25, 50, 100
- Preserve query parameters
- Accessible navigation

Do not implement pagination by loading every post into Alpine.js.

---

# 3. INDIVIDUAL AND BULK SELECTION

Implement:

- Select one post
- Select multiple posts
- Select all posts on the current page
- Deselect individual posts
- Clear selection
- Display selected record count
- Contextual bulk-action toolbar

Optionally support selecting all records matching the current filters across pages.

Never silently include unselected records.

### Bulk actions

Support:

- Move to Draft
- Publish
- Move to Trash
- Restore
- Permanently Delete from Trash

Require confirmation for destructive operations.

Validate every selected ID server-side.

Use authorization checks and database transactions where appropriate.

Do not allow duplicate submissions.

Report partial failures clearly.

---

# 4. TRASH AND RESTORE SYSTEM

Implement a professional WordPress-style Trash workflow.

### Requirements

- Soft delete posts.
- Deleted posts disappear from normal listings.
- Trash has its own filtered view.
- Restore returns a post to its previous lifecycle state when safe.
- Permanent deletion is only available from Trash.
- Confirm permanent deletion.
- Support individual and bulk restoration.
- Support individual and bulk permanent deletion.

Preserve translation relationships during soft deletion.

Inspect the existing schema before adding Laravel SoftDeletes.

Avoid destructive migrations.

If the project stores revisions, media references, or translation relationships, handle deletion consistently.

Do not delete shared images simply because a post is deleted.

---

# 5. CREATE / EDIT POST — EDITOR LAYOUT

Preserve the current two-column composition:

### Main content area

- Post title
- WordPress-style permalink
- Rich-text editor
- Language/translation editing
- Content preview

### Right settings sidebar

- Publication settings
- Category
- Tags
- Featured image
- SEO settings
- Optional advanced settings

The sidebar should use collapsible sections to avoid excessive vertical scrolling.

On smaller screens, stack the sidebar below the editor or provide an accessible settings panel.

Do not remove existing image metadata controls.

---

# 6. WORDPRESS-STYLE AUTOMATIC SLUG

Move the slug control from the large Post Settings sidebar to a compact permalink area immediately below the post title.

### Expected behavior

When the user enters a title, automatically generate a slug.

Example:

Title:
What Is Temporary Email?

Generated slug:
what-is-temporary-email

Display:

Permalink:
`/en/blog/what-is-temporary-email`

Provide a small Edit action.

Clicking Edit expands an editable slug input.

### Important rules

- Generate the slug from the title.
- Normalize Unicode safely.
- Support the project's existing slug conventions.
- Ensure uniqueness within the actual route namespace.
- Never overwrite a manually customized slug.
- Never silently change an existing published URL.
- Validate slug conflicts server-side.
- Show the final permalink preview.
- Use the application's actual public route structure rather than assuming `/en/blog/` is already implemented.

### Published slug changes

If a published post's slug changes:

- Preserve the previous URL.
- Create a 301 redirect where supported.
- Prevent redirect loops.
- Avoid duplicate redirect records.
- Respect language-specific URLs.

Use a dedicated redirect model only if the existing architecture requires it.

Do not add unnecessary database structures.

---

# 7. MULTILINGUAL POST ARCHITECTURE — 30 LANGUAGES

The application supports these locales:

en, ar, bn, zh, cs, nl, fr, de, el, he, hi, id, it, ja, ko, ms, fa, pl, pt, ro, ru, es, sw, sv, ta, th, tr, uk, ur, vi.

### Critical architecture requirement

Do not create 30 unrelated posts for 30 translations of the same article.

Use a shared logical post with language-specific content records, unless the existing architecture already provides an equivalent normalized solution.

Suggested conceptual structure:

**posts**

- id
- lifecycle metadata
- publication settings
- timestamps
- soft deletion

**post_translations**

- id
- post_id
- locale
- title
- slug
- body
- excerpt
- seo_title
- seo_description
- translation status
- language-specific publication metadata where required

This is a conceptual recommendation, not permission to replace existing tables automatically.

Inspect the current schema and choose the smallest safe migration path.

### Multilingual editor UX

Provide language tabs or a searchable language selector.

Example:

English — Published  
Turkish — Published  
Arabic — Draft  
German — Missing

Each translation should support its own:

- Title
- Slug
- Content
- Excerpt
- SEO title
- SEO description
- Translation status

### Translation actions

- Add translation
- Edit translation
- Save translation draft
- Publish translation
- Unpublish translation
- Preview translation

Do not automatically publish incomplete translations.

Do not automatically duplicate English content into every language.

### Translation fallback

A missing translation must not appear as a completed translation.

English fallback should not be counted as genuine translation coverage.

Do not expose draft translations publicly.

Only generate `hreflang` links for published equivalent translations with valid public URLs.

---

# 8. RICH-TEXT EDITOR

The existing editor already supports:

- Bold
- Italic
- Headings
- Bullet lists
- Numbered lists
- Quotes
- Code blocks
- Dividers
- Links
- Images
- Undo
- Redo
- Slash commands

**Preserve these features.**

Improve the editor only where necessary.

### Recommended improvements

- H2/H3 heading choices
- Clear formatting
- Keyboard shortcuts
- Word count
- Reading-time estimate
- Unsaved changes indicator
- Fullscreen/focus mode, if useful
- Better image insertion workflow
- Accessible toolbar states

Do not replace the existing editor with a heavy third-party package unless there is a demonstrated technical limitation.

### Content security

- Validate editor documents server-side.
- Sanitize rendered HTML.
- Reject unsafe URLs and scripts.
- Preserve allowed formatting.
- Prevent stored XSS.
- Handle embedded images securely.

---

# 9. PUBLICATION WORKFLOW

Support these lifecycle states:

- Draft
- Published
- Scheduled

Keep Trash as a soft-deletion state rather than mixing it into ordinary publication status when that fits the existing model.

### Publication controls

In the right sidebar, provide:

- Status
- Publish immediately
- Schedule publication
- Publication date and time
- Preview
- Save draft
- Publish / Update

Use clear primary and secondary button hierarchy.

### Scheduling

If scheduled publishing is implemented:

- Use Laravel's scheduler or existing scheduling infrastructure.
- Store dates consistently.
- Respect the application's configured timezone.
- Handle daylight-saving changes.
- Prevent premature publication.
- Ensure scheduled content is not visible publicly before its publish time.

Do not claim scheduling works without implementing the backend execution path.

---

# 10. CATEGORIES AND TAGS

Preserve the existing Blog → Categories and Blog → Tags navigation.

### Categories

Support:

- Search
- Sorting
- Pagination
- Individual selection
- Select all
- Bulk actions
- Active/inactive status only if meaningful to the existing business rules
- Safe deletion
- Post relationship management

### Tags

Support:

- Search
- Sorting
- Pagination
- Individual selection
- Select all
- Bulk actions
- Safe deletion
- Post relationship management

### Multilingual taxonomy

Inspect whether categories and tags already support translations.

If not, design language-specific labels and slugs while preserving shared category/tag identities.

Do not create 30 unrelated category records for one translated category.

Do not automatically delete posts when a category or tag is removed.

### Create Post UX

Use:

- Searchable category selector
- Searchable tag selection
- Selected-tag chips
- Clear selection controls

Do not require a heavy JavaScript select library.

---

# 11. COVER IMAGE AND MEDIA LIBRARY

Preserve the existing Images integration.

Improve the featured-image experience:

- Select from existing media library
- Show image preview
- Replace image
- Remove image
- Display dimensions where available
- Preserve alt text
- Preserve decorative-image setting
- Preserve optional caption

Use the existing image metadata and language fallback behavior.

Avoid unnecessary duplicate uploads.

Never delete shared media when a post is moved to Trash.

---

# 12. SEO SETTINGS

Add a collapsible SEO section to the Post Settings sidebar.

For each language-specific post translation, support:

- SEO title
- Meta description
- Canonical URL handling
- Open Graph title
- Open Graph description
- Social sharing image, if supported

Provide a simple search-result preview.

### SEO rules

- Use safe defaults when optional metadata is missing.
- Allow manual overrides.
- Validate metadata lengths appropriately.
- Avoid duplicate canonical tags.
- Avoid publishing draft URLs in sitemaps.
- Generate multilingual `hreflang` only for published translations.
- Respect existing public routing.
- Avoid duplicate SEO metadata logic.

Do not implement arbitrary SEO scoring or AI-generated SEO content.

---

# 13. REVISION HISTORY

Implement lightweight post revision history where practical.

Support:

- Previous saved versions
- Revision timestamp
- Editor identity when available
- Revision preview
- Restore previous revision

Do not create a revision on every keystroke.

Limit unnecessary storage growth.

Preserve language-specific revision history.

Restoring a revision must not silently publish a draft.

---

# 14. AUTOSAVE AND UNSAVED CHANGES

Implement reliable dirty-state tracking.

Requirements:

- Detect unsaved changes.
- Warn before accidental navigation.
- Preserve input after validation errors.
- Avoid duplicate saves.
- Display clear save feedback.

Optional autosave:

- Save only when content has changed.
- Use a reasonable debounce interval.
- Do not overwrite a newer server version.
- Do not silently publish content.
- Handle network errors clearly.

Prefer an incremental implementation.

Do not build a complex real-time collaboration system.

---

# 15. PAGES MODULE

Keep Pages as a separate top-level administration menu.

Reuse the existing rich-text editor, image components, SEO controls, and multilingual architecture where appropriate.

Pages should support:

- Title
- Slug
- Content
- Language translations
- Draft / Published / Scheduled
- Preview
- SEO metadata
- Trash and Restore
- Pagination
- Search and filtering
- Individual and bulk actions

Page-specific optional fields:

- Parent page
- Display order
- Page template

Do not force blog categories or tags onto Pages.

Avoid duplicating the entire Posts implementation.

Share reusable services and Blade components, but keep post-specific and page-specific business rules separate.

---

# 16. REUSABLE BLADE COMPONENTS

Inspect existing components before creating new ones.

Consider meaningful reuse for:

- Data table
- Table filters
- Pagination
- Bulk-action toolbar
- Status indicator
- Confirmation dialog
- Slug/permalink editor
- Rich-text editor wrapper
- Publication settings
- Media picker
- SEO fields
- Language selector
- Translation status
- Empty state

Avoid creating a component for every HTML element.

Follow existing naming conventions.

---

# 17. UX/UI REQUIREMENTS

Preserve the current Temp Mail SaaS visual language:

- Dark and light appearance support
- Mint-green primary actions
- Neutral backgrounds
- Subtle borders
- Compact typography
- Rounded panels
- Existing sidebar
- Existing icon style

Improve:

- Visual hierarchy
- Table density
- Form organization
- Responsive behavior
- Keyboard navigation
- Error feedback
- Empty states
- Loading states

Avoid:

- Oversized cards
- Excessive shadows
- Unnecessary gradients
- Cluttered toolbars
- Too many always-expanded settings
- Heavy animations
- Unnecessary dependencies

Target WCAG 2.2 AA accessibility.

---

# 18. BACKEND ENGINEERING

Use Laravel conventions.

Prefer:

- Form Request validation
- Policies and Gates
- Eloquent relationships
- Query scopes
- Native pagination
- Database transactions
- Named routes
- CSRF protection
- SoftDeletes where appropriate
- Focused services for complex operations

Ensure:

- Efficient multilingual queries
- No N+1 problems
- Proper database indexes
- Safe bulk actions
- Unique locale-specific slugs
- Correct deletion semantics
- Authorization on every mutation
- Secure rich-text rendering

Do not introduce React, Vue, Inertia, Livewire, or unnecessary packages.

---

# 19. TESTING REQUIREMENTS

Add or update tests for:

### Posts listing

- Search
- Filters
- Sorting
- Pagination
- Bulk selection handling
- Authorization

### Post lifecycle

- Draft creation
- Publishing
- Scheduling
- Unpublishing
- Soft deletion
- Restoration
- Permanent deletion

### Slugs

- Automatic generation
- Manual override
- Uniqueness
- Unicode normalization
- Published slug changes
- Redirect behavior

### Multilingual content

- Translation creation
- Translation editing
- Missing translation detection
- Language-specific slugs
- Publication visibility
- RTL support
- `hreflang` correctness

### Editor and media

- Content validation
- XSS prevention
- Image relationships
- SEO metadata
- Unsaved changes handling where testable

### Regression

- Existing Categories functionality
- Existing Tags functionality
- Existing Pages functionality
- Existing Language management
- Existing Images integration

Do not report tests as passing unless they actually ran successfully.

---

# 20. IMPLEMENTATION ORDER

Follow this sequence carefully.

### Phase 1 — Audit

Inspect the existing project.

Identify:

- Current models
- Controllers
- Routes
- Migrations
- Blade components
- Rich-text editor implementation
- Translation architecture
- Post status handling
- Existing tests

Provide a concise audit and implementation plan.

### Phase 2 — Posts Management

Implement:

- Data table
- Search
- Filters
- Sorting
- Pagination
- Selection
- Bulk actions
- Trash and Restore

### Phase 3 — Create/Edit Post UX

Implement:

- Automatic permalink below title
- Collapsible post settings
- Improved publication controls
- Editor usability improvements
- Unsaved changes protection

### Phase 4 — Multilingual Content

Implement or safely extend:

- Shared post identity
- Language-specific content
- Translation management
- Language-specific slugs
- Publication rules
- RTL support

### Phase 5 — SEO and Publishing

Implement:

- SEO fields
- Preview
- Scheduling where supported
- Redirect handling
- Published-only sitemap and `hreflang` behavior

### Phase 6 — Reuse

Apply relevant reusable components and proven workflows to:

- Categories
- Tags
- Pages

Do not introduce unrelated redesigns.

### Phase 7 — Quality Assurance

- Run relevant tests.
- Run existing build checks.
- Fix regressions.
- Verify responsive behavior.
- Verify dark/light themes.
- Summarize modified files.
- Report any incomplete functionality honestly.

---

# STRICT IMPLEMENTATION RULES

1. Do not rebuild the application.
2. Do not change the existing design identity.
3. Do not remove existing editor functionality.
4. Do not create 30 independent posts for translations of one article.
5. Do not invent backend functionality.
6. Do not make destructive schema changes without inspecting existing data.
7. Do not introduce unnecessary third-party packages.
8. Do not modify unrelated modules.
9. Do not generate fake production content.
10. Do not implement decorative buttons without working behavior.
11. Do not silently change published URLs.
12. Do not expose unpublished translations publicly.
13. Do not delete shared media during post deletion.
14. Do not sacrifice security, accessibility, or performance.
15. Do not claim success without running relevant checks.

# FINAL EXPECTATION

Deliver a professional multilingual CMS integrated into the existing Temp Mail SaaS administration panel.

The Posts module must include:

**Professional Data Table + Search + Filters + Sorting + Pagination + Select All + Bulk Actions + Trash + Restore + Automatic Slug + Rich-Text Editor + 30-Language Translation Management + SEO + Draft/Publish/Schedule + Preview.**

The Categories, Tags, and Pages modules should reuse the same design patterns where appropriate.

**START WITH A COMPLETE AUDIT OF THE EXISTING CODEBASE. THEN IMPLEMENT PHASES IN ORDER, KEEPING THE APPLICATION WORKING AFTER EACH PHASE.**