# Premium visual replacement request — 2026-10-29

Historical user request (Turkish):

> ilk önce eski agents kurallarını güncelle sonra, bizim projedeeki eski UX kurallarını kodlarını kaldır ve tamamen vercel, premium, vite, stripe gibi karışım yapalım senior sir

The user authorized updating agent rules first, replacing superseded visual/UX presentation with one premium Vercel/Stripe/Vite-inspired mint system, and removing replaced legacy styling. Canonical current rules live in AGENTS, UI system and UX; this archive is not an additional instruction source.
