# ROLE: Principal Laravel 13 Architect, Senior SaaS UX/UI Engineer & Localization Specialist

## PROJECT CONTEXT

I am developing a multilingual **Temp Mail SaaS** application supporting 30 languages.

Current technology stack:

- Laravel 13
- Laravel Blade Components
- Tailwind CSS
- Alpine.js
- Vite
- Server-side rendering

The existing administration interface features a minimal dark/light design, subtle green accents, rounded panels, compact typography, and sidebar navigation.

**Preserve the existing visual identity and architecture. Do not rebuild the application.**

## PRIMARY TASK

Improve the existing **Edit Translations** page, currently accessible through language-specific routes such as `/languages/ar/edit`.

The current editor displays eight homepage translation keys, with the fixed English source on the left and the target-language translation on the right.

This structure works but must become scalable, efficient, and maintainable as the Temp Mail SaaS platform grows.

Create a professional, category-based translation management experience without breaking existing functionality.

## 1. PRESERVE EXISTING FUNCTIONALITY

Before modifying anything:

- Inspect existing language routes.
- Inspect controllers, services, models, and validation.
- Inspect translation storage and fallback behavior.
- Inspect the existing eight homepage translation keys.
- Inspect the current save mechanism.
- Inspect the English source handling.
- Inspect existing Blade components and styles.

Preserve all working functionality.

Do not replace the current translation architecture without a demonstrated reason.

## 2. EDITOR PAGE STRUCTURE

Create a clean, professional layout with:

### Header

Display:

- Target language name
- Native language name
- Locale code
- RTL/LTR indicator
- Back to Languages
- Save Changes

Example:

Arabic Translations  
English Source → العربية  
Locale: AR · RTL

### Compact Statistics

Show:

- Total translation keys
- Translated keys
- Missing translations
- Customized translations
- Unsaved changes

Calculate all values from actual translation data.

Do not confuse bundled translations with customized translations.

## 3. CATEGORY-BASED TRANSLATION MANAGEMENT

Design an extensible translation editor with categories.

Suggested categories:

- Homepage
- Mailbox
- Navigation
- Notifications
- SEO
- FAQ
- Footer

Important:

These categories are architectural targets, not permission to invent new functionality.

Inspect the existing application and create categories only for translation keys that actually exist.

Preserve the existing homepage translation keys.

Do not generate fake translations or add unrelated database records.

Make it easy to add future translation groups without duplicating controllers or Blade pages.

## 4. TRANSLATION EDITOR UX

For each translation key, display:

- Human-readable field name
- Translation key identifier
- Read-only English source
- Editable target-language translation
- Translation status
- Reset to bundled translation action when supported

Use a compact two-column layout on desktop.

English source: left column  
Target translation: right column

On mobile, stack the fields vertically.

Avoid unnecessarily large cards and excessive vertical spacing.

Use textarea for longer content and appropriate single-line inputs for short labels.

Preserve newlines where meaningful.

## 5. TRANSLATION STATUS SYSTEM

Clearly distinguish:

**Bundled**
A translation supplied by the application's language resources.

**Customized**
A translation overridden by an administrator.

**Missing**
No target-language translation exists.

**Fallback**
The interface is displaying a fallback-language value rather than a genuine target-language translation.

Do not treat English fallback as completed translation coverage.

Display status using subtle badges or text indicators.

Calculate translation completeness accurately.

## 6. SEARCH AND FILTERING

Implement:

- Search by translation key
- Search by English source text
- Search by target translation
- Filter by category
- Filter by translation status
- Show missing translations only
- Clear all filters

Keep filtering responsive and predictable.

For small translation datasets, lightweight Alpine.js filtering is acceptable.

For larger datasets, use Laravel server-side filtering and pagination.

Do not introduce heavy JavaScript frameworks.

## 7. UNSAVED CHANGES PROTECTION

Implement reliable dirty-state tracking.

Requirements:

- Detect modified translation fields.
- Display the number of unsaved changes.
- Highlight modified fields subtly.
- Warn users before navigating away with unsaved changes.
- Avoid warnings after successful saves.
- Prevent accidental duplicate submissions.
- Preserve entered values after validation errors.

Use browser-native navigation protection where appropriate.

Do not create intrusive confirmation dialogs for ordinary editing.

## 8. SAVE AND RESET BEHAVIOR

Preserve the existing save endpoint and validation contracts unless a change is necessary.

Support:

- Save all modified translations
- Clear success messages
- Validation feedback beside affected fields
- Reset an individual customization to its bundled translation
- Clear indication of what resetting does

Important:

If clearing a field currently removes the customization and restores a bundled translation, preserve that behavior.

Do not silently overwrite or delete translation resources.

Do not confuse resetting a customization with deleting a translation key.

## 9. RTL AND INTERNATIONALIZATION

Support all 30 locales:

en, ar, bn, zh, cs, nl, fr, de, el, he, hi, id, it, ja, ko, ms, fa, pl, pt, ro, ru, es, sw, sv, ta, th, tr, uk, ur, vi.

RTL languages:

- Arabic
- Hebrew
- Persian
- Urdu

Requirements:

- Apply correct direction to target-language inputs.
- Keep English source content LTR.
- Use appropriate `lang` and `dir` attributes.
- Preserve readable email addresses, URLs, and placeholders.
- Support non-Latin scripts.
- Handle long translated text gracefully.
- Avoid direction-dependent spacing assumptions.

Keep the administration navigation in its existing language unless localization is explicitly required.

## 10. PLACEHOLDER VALIDATION

Protect dynamic translation placeholders.

Examples:

- `:count`
- `:email`
- `:domain`
- `{name}`

Inspect the project's actual placeholder conventions before implementing validation.

Ensure translations do not accidentally remove, duplicate, or corrupt required placeholders.

Validate server-side and display actionable error messages.

Do not introduce placeholder formats that the existing translation engine does not support.

## 11. TRANSLATION PREVIEW

Improve the existing "Preview resolved text" section.

Provide:

- Preview of resolved translations
- Clear distinction between custom, bundled, and fallback values
- Correct RTL/LTR rendering
- Readable formatting
- Optional live preview of unsaved edits

Do not misrepresent an unsaved preview as published content.

Keep the preview lightweight.

## 12. TEMP MAIL SAAS-SPECIFIC FUTURE SUPPORT

Design the translation architecture to accommodate future public-facing text such as:

### Mailbox
- Generate email address
- Copy address
- Refresh inbox
- Delete address
- Inbox empty state
- Incoming message notifications

### Notifications
- Address copied
- Mailbox created
- Message received
- Generic errors

### SEO
- Meta title
- Meta description
- Open Graph title and description

### Navigation and Footer
- Menu labels
- Footer links
- Informational text

These are examples of future translation domains.

Do not implement features that do not already exist.

Do not add these keys until their corresponding functionality is present or explicitly requested.

## 13. PERFORMANCE AND ARCHITECTURE

Use Laravel Blade Components for meaningful reusable UI.

Potential components:

- Translation editor layout
- Translation category navigation
- Translation field row
- Translation status indicator
- Translation search/filter toolbar
- Unsaved changes indicator
- Translation preview

Avoid excessive component nesting.

Use Alpine.js for lightweight client-side behavior.

Keep translation persistence, validation, authorization, and fallback resolution on the Laravel server.

Do not introduce React, Vue, Livewire, Inertia, or unnecessary packages.

## 14. ACCESSIBILITY

Target WCAG 2.2 AA.

Ensure:

- Semantic HTML
- Proper input labels
- Visible focus states
- Keyboard navigation
- Accessible status announcements
- Accessible validation messages
- Mobile-friendly inputs
- Correct RTL handling
- No unnecessary animations

## 15. TESTING

Add focused tests for:

- Loading the correct locale
- English source protection
- Saving translations
- Resetting custom translations
- Bundled fallback resolution
- Missing translation detection
- Placeholder preservation
- Authorization
- Invalid locale handling
- Validation errors
- RTL rendering
- Existing route compatibility

Test that all existing homepage translations continue working.

## 16. IMPLEMENTATION WORKFLOW

Follow this order:

1. Audit the existing translation implementation.
2. Identify reusable components and working functionality.
3. Identify verified UX and architectural limitations.
4. Propose a minimal improvement plan.
5. Implement the editor improvements incrementally.
6. Preserve all existing translations and endpoints.
7. Add focused tests.
8. Run relevant checks.
9. Summarize modified files and remaining limitations.

## STRICT RULES

- Do not rebuild the project.
- Do not change the existing design system.
- Do not modify unrelated administration pages.
- Do not remove existing translations.
- Do not generate fake translation data.
- Do not change database schemas unnecessarily.
- Do not introduce unnecessary dependencies.
- Do not break existing language management.
- Do not duplicate translation logic.
- Do not create separate Blade editors for each language.
- Do not invent functionality.
- Do not sacrifice accessibility or performance.

## FINAL EXPECTATION

Deliver a professional, scalable **Edit Translations** experience with:

- Category navigation
- Translation search
- Status filtering
- English source comparison
- Editable target-language translations
- Accurate translation progress
- Unsaved changes protection
- Safe save and reset behavior
- Resolved translation preview
- Full RTL/LTR support
- Reusable Laravel Blade architecture

The result should integrate naturally with the existing 30-language management table and Temp Mail SaaS administration design.

**START NOW: Inspect the existing project and identify the smallest safe improvements. Then implement the approved changes incrementally without breaking existing functionality.**