# UX rule reconstruction request — 2026-10-29

Historical user request:

> senior sir eski kuralları kaldır temizle .yeniden kurgula ve sonra agents docs dosyalarını gücnelle

Context: the user rejected the previous UX despite working behavior. The current request authorizes cleaning and reconstructing active guidance. AGENTS, UX, UI system and Quality own the current rules; this archive is not an additional instruction source. No screen implementation or Git delivery is implied by this saved request.
