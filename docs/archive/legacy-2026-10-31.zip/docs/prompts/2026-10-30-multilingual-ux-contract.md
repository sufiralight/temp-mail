# ROLE
Principal SaaS Product Designer, Staff Laravel 13 Engineer, Multilingual CMS Architect, UX Systems Lead

# PROJECT
Temp Mail SaaS — 30-Language Platform

Stack:
- Laravel 13
- Blade Components
- Tailwind CSS
- Alpine.js
- Vite
- Server-side rendering
- Existing rich-text editor

# MISSION

Build one coherent, premium, production-grade UX across the entire Temp Mail SaaS application.

Design quality references:
- Linear: fast, predictable interactions
- Vercel: minimal, focused layouts
- Stripe: precise tables, forms, and feedback
- WordPress: intuitive publishing workflows

Do not copy their visual designs.

Preserve the existing Temp Mail SaaS brand, dark/light themes, and mint/turquoise accent.

**Do not redesign the project from scratch. Fix the existing architecture, establish shared standards, and apply them consistently.**

---

# 1. READ PROJECT RULES FIRST

Before changing any code, inspect:

- AGENTS.md and nested agent instructions
- agents/
- docs/
- CLAUDE.md, if present
- .cursor/rules/, if present
- Existing design-system documentation
- Existing Laravel architecture
- Existing Blade components
- Existing Alpine components
- Existing translation infrastructure

Do not overwrite established project rules.

Update the canonical documentation with any new decisions.

Make future coding sessions follow these standards without repeated prompting.

# 2. GLOBAL UX PRINCIPLES

Every screen must follow these rules:

1. One clear primary action per context.
2. Consistent page headers and action placement.
3. Predictable navigation.
4. Compact, readable information density.
5. Progressive disclosure for advanced settings.
6. Clear save, loading, success, and error states.
7. No duplicated controls for the same action.
8. No decorative controls without functionality.
9. No unnecessary full-page reloads.
10. No accidental data loss.
11. Accessible keyboard interaction.
12. Responsive behavior designed intentionally.
13. Consistent dark/light theme behavior.
14. Full Unicode and RTL/LTR support.

Premium UX means fewer decisions, fewer surprises, and reliable behavior.

# 3. SHARED DESIGN SYSTEM

Create or refine semantic design tokens for:

- Backgrounds
- Surfaces
- Borders
- Typography
- Brand colors
- Interactive states
- Status colors
- Focus indicators
- Spacing
- Radii
- Layout widths

Reuse existing components where possible.

Standardize:

- Page headers
- Buttons
- Form fields
- Dropdowns
- Tabs
- Data tables
- Pagination
- Dialogs
- Toasts
- Empty states
- Loading states
- Sidebars
- Editor toolbars
- Settings panels

All administration modules must share the same visual and interaction standards.

Public-facing pages must share the brand identity without being forced into the administration layout.

# 4. CREATE/EDIT POST — PRIMARY UX

Use a focused writing interface.

Page hierarchy:

1. Page title and save actions
2. Content language selector
3. Post title
4. Compact permalink editor
5. Rich-text content editor
6. Excerpt
7. Collapsible settings sidebar

The main writing area should remain visually dominant.

Avoid unnecessary cards around every field.

Keep the settings sidebar compact.

# 5. SINGLE CONTENT LANGUAGE CONTROL

Remove confusing duplicate language-selection controls.

Provide one authoritative, searchable Content Language selector supporting all 30 configured locales.

Display:

- Language name
- Native language name
- Locale code
- Translation status

After a post is created, provide a clear Translations management interface.

Statuses:

- Published
- Draft
- Missing

Switching languages must not publish or save implicitly.

# 6. CRITICAL — LOCALE-ISOLATED EDITOR STATE

Fix the existing bug where a slug from one language remains visible after switching to another language.

Each locale must maintain independent:

- Title
- Slug
- Body
- Excerpt
- SEO title
- SEO description
- Manual slug override
- Dirty state

Use one authoritative active locale.

Maintain translation drafts indexed by locale.

Conceptual structure:

translations[locale].title
translations[locale].slug
translations[locale].body
translations[locale].excerpt
translations[locale].seoTitle
translations[locale].seoDescription
translations[locale].slugManuallyEdited

Adapt to the existing architecture.

When switching locales:

1. Preserve the outgoing locale's unsaved data.
2. Load the incoming locale's saved or draft data.
3. Show empty fields for missing translations.
4. Update the permalink.
5. Update the editor document.
6. Update text direction.
7. Update dirty-state indicators.
8. Never overwrite another locale.

Switching back must restore unsaved content.

# 7. AUTOMATIC SLUG UX

Place a compact permalink directly below the title.

Example:

Title:
What Is Temporary Email?

Permalink:
`/en/blog/what-is-temporary-email`

Provide an Edit action.

Requirements:

- Generate from the active locale's title.
- Support manual customization.
- Preserve manual overrides per locale.
- Validate uniqueness within the correct namespace.
- Handle Unicode safely.
- Keep URL previews LTR.
- Never silently change published URLs.
- Preserve old published URLs using redirects where appropriate.

Do not assume a particular public route structure.

Inspect actual routes.

# 8. FIX RTL/LTR BEHAVIOR

RTL locales:

- Arabic
- Persian
- Hebrew
- Urdu

All other configured locales should use their canonical configured direction.

Apply `lang` and `dir` to the actual editable content surfaces.

When switching Arabic to English or Turkish:

- The editor must become LTR.
- The cursor and paragraph alignment must behave correctly.
- Previous RTL state must not leak into the new locale.

When switching English to Arabic:

- The editor must become RTL.
- Text entry and cursor behavior must work correctly.

Keep the administration shell in its own interface direction.

Do not reverse the entire admin panel when only the content language changes.

Verify the actual rich-text editor implementation and lifecycle.

# 9. CONTENT TRANSLATION WORKFLOW

Use one logical post with localized translations.

Recommended user journey:

1. Create the original post in a selected language.
2. Save the draft.
3. Open Translations.
4. Choose another language.
5. Add a translation.
6. Edit and save its draft.
7. Publish the translation independently when ready.

Do not create 30 unrelated posts.

Do not auto-fill missing translations with English and mark them complete.

Translation coverage must reflect real content availability.

# 10. SHARED POST SETTINGS

Keep shared post metadata separate from localized content.

Shared settings may include:

- Category relationships
- Tag relationships
- Featured image
- Other existing post-level metadata

Localized settings may include:

- Title
- Slug
- Body
- Excerpt
- SEO title
- SEO description
- Publication status, according to the established content model

Clearly distinguish shared changes from language-specific changes.

Never make users guess whether a change affects one language or all languages.

# 11. FEATURED IMAGE UX

Integrate the existing Images module directly into the editor.

Provide:

- Select image
- Search media
- Thumbnail gallery
- Image preview
- Confirm selection
- Replace image
- Remove image
- Alt text
- Decorative image setting
- Optional caption

Use the existing media storage and authorization rules.

Do not create a duplicate media system.

# 12. POSTS, PAGES, CATEGORIES, TAGS

Use consistent management patterns.

Where appropriate:

- Search
- Filters
- Sorting
- Numbered pagination
- Individual selection
- Select current page
- Bulk actions
- Trash
- Restore
- Permanent deletion confirmation

Posts and Pages must support localized content.

Categories and Tags must support localized names and slugs under shared identities.

Do not delete associated posts when removing taxonomy relationships.

# 13. TRANSLATION EDITOR

Keep fixed interface translations separate from dynamic CMS content.

The Language → Edit Translations interface must use:

- Category-based organization
- Search
- Translation status filters
- English source comparison
- Target-language editing
- Accurate completion statistics
- Unsaved changes protection
- RTL/LTR handling
- Resolved translation preview

Do not count English fallback as a completed target-language translation.

# 14. SAVE EXPERIENCE

Standardize save feedback:

- Saved
- Unsaved changes
- Saving…
- Save failed

Disable duplicate submissions.

Show actionable validation errors.

Preserve entered data after errors.

Protect unsaved work when:

- Switching languages
- Navigating away
- Closing an editor
- Changing tabs

Use nonintrusive notifications.

Do not display success before the server confirms persistence.

# 15. PERFORMANCE AND ACCESSIBILITY

Keep Blade server rendering as the default.

Use Alpine.js only for lightweight interactions.

Avoid unnecessary packages and frontend frameworks.

Target WCAG 2.2 AA.

Verify:

- Keyboard navigation
- Focus states
- Contrast
- Form labels
- Dialog focus management
- Screen-reader feedback
- Reduced-motion preferences
- Mobile usability
- RTL/LTR editing

# 16. AUTOMATED REGRESSION TESTS

Prioritize tests for the known bugs:

- English title generates English slug.
- Switching to Turkish shows independent Turkish data.
- Returning to English restores English data.
- Manual slug overrides remain independent.
- Arabic editor uses RTL.
- Turkish editor uses LTR.
- Arabic → English resets editor direction.
- Unsaved content survives locale switching.
- Saving one locale does not overwrite another.
- Featured image selection persists.
- Trash and Restore work.
- Existing routes and translations remain compatible.

Use browser-level tests for rich-text editor behavior where available.

Do not claim tests passed unless executed.

# 17. IMPLEMENTATION STRATEGY

Phase 1 — Audit existing agents, docs, architecture, and components.

Phase 2 — Reproduce and fix multilingual state and direction bugs.

Phase 3 — Standardize the Create/Edit Post UX.

Phase 4 — Establish reusable design tokens and Blade components.

Phase 5 — Apply shared UX patterns across Posts, Pages, Categories, Tags, Languages, Images, Dashboard, and Account.

Phase 6 — Apply appropriate shared brand patterns to the public website.

Phase 7 — Run regression, accessibility, responsive, and build checks.

Work incrementally.

Keep the application functioning after each phase.

# 18. PERMANENT AGENT CONTRACT

Update the existing project agent instructions so future tasks automatically:

- Read the canonical design-system documentation.
- Reuse established components.
- Follow the multilingual editor contract.
- Respect shared versus localized data.
- Preserve unsaved state.
- Verify RTL/LTR behavior.
- Follow the same table and form patterns.
- Test functionality before declaring completion.
- Update documentation when standards change.

Do not duplicate full instructions across multiple files.

# STRICT RULES

- Do not rebuild the application.
- Do not change the existing technology stack.
- Do not introduce React, Vue, Livewire, or Inertia.
- Do not create 30 unrelated posts for one article.
- Do not overwrite translations across locales.
- Do not use cosmetic CSS fixes for state-management bugs.
- Do not introduce unnecessary dependencies.
- Do not remove existing functionality.
- Do not create nonfunctional controls.
- Do not perform destructive migrations.
- Do not claim successful implementation without verification.

# DEFINITION OF DONE

The project is complete for this task when:

1. The multilingual editor correctly isolates all locale-specific data.
2. RTL/LTR switching works in the actual rich-text editor.
3. Automatic slugs behave independently per language.
4. Unsaved content survives language switching.
5. Shared and localized settings are clearly separated.
6. The CMS modules follow consistent management patterns.
7. The entire application uses one coherent design system.
8. Existing functionality is preserved.
9. Relevant tests and builds pass.
10. Future agent sessions are guided by the documented project standards.

# START NOW

Inspect the repository and existing agent instructions.

Reproduce the reported multilingual editor bugs first.

Fix the root causes before performing cosmetic changes.

Then implement the shared premium UX foundation and apply it incrementally across the project.

Report the actual changed files, test results, and any remaining limitations.