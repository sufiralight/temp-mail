# Public presentation contracts

[UX](ux.md) owns task definition and [Quality](quality.md) separates functional, visual and task-flow evidence. Follow the current multilingual UX contract and preserve the Temp Mail mint/turquoise identity. Public reading shares tokens and controls while retaining a separate composition from administration.

Existing public Blog/Post and informational Page output uses x-public-layout and x-document-head, sharing brand tokens, fonts, appearance and accessibility with administration. Its reading shell has no admin sidebar, account identity or management table. Keep existing publication, preview, media permissions, canonical/hreflang/OG and sitemap behavior unchanged. Locale rules belong to [Internationalization](internationalization.md).

| Screen | Presentation contract | Current scope |
| --- | --- | --- |
| Article / informational page | One h1, readable rich content, intrinsic media, use-specific alt/caption, native published-language links | Implemented renderer; visual and task acceptance remain subject to the current review. |
| Homepage | Clear service purpose, one primary action, concise supporting sections, honest service state | Deferred; existing fixed homepage catalogs are retained. |
| Temporary mailbox / inbox | Address/action hierarchy, safe copy feedback, real refresh/loading/error/empty states, responsive message list | Future presentation only; no receiving/forwarding backend exists. |
| Email message | Sender/subject/time hierarchy, safe content boundary and keyboard return path; no trusted arbitrary email HTML | Future presentation only; backend/security design requires separate approval. |
| Blog/category/tag listing | Reader-facing summaries, meaningful pagination/filter links, useful empty state; no admin bulk controls | Public archives are not implemented. |
| Errors | Plain reason, safe recovery link, no debug details or leaked secrets | The existing errors/minimal view is an English guest layout using shared tokens and document assets. Status-specific public localization is a future refinement; do not claim it is already localized. |

Reuse the public shell for approved future screens; do not prebuild inactive routes, fake inbox metrics or dead controls. Brand name remains Temp Mail SaaS. Public fixed copy comes from catalogs, dynamic content from its actual saved locale. Loading states must reflect real asynchronous work. Use [Quality](quality.md) before delivering a public page.

Published language variants are grouped in a native disclosure to keep long multilingual link sets compact on mobile. Native names and isolated locale codes remain keyboard-accessible and present in server HTML without JavaScript.
