# Quality and delivery

## Three independent checks

A screen is ready only when the checks below are addressed with evidence appropriate to the change. Passing one does not establish the others. Current implementation and historical test results are not proof of user acceptance.

| Check | Required evidence | What it does not prove |
| --- | --- | --- |
| Functional correctness | Relevant persistence/validation/authorization/native-fallback tests; every changed control reaches a real outcome | Visual quality or ease of use |
| Visual coherence | Inspect real rendered output for hierarchy, alignment, readability, density, states and shared identity in relevant themes/viewports/locales | Representative task completion or WCAG conformance |
| Task flow | Walk through the screen brief's primary action and relevant recovery path; record friction, next-action clarity and retained context | A formal user study or universal user satisfaction |

Do not call a result premium, intuitive, accessible or performance-improved merely because a build or screenshot exists. Report what was checked, what was found and what remains unmeasured.

## Working sequence

1. Read AGENTS, Scope, the owning feature document and UX. Inspect existing code/components and describe the task/problem before styling.
2. For substantial redesigns, build and review a bounded reference before propagating it. Routine fixes stay within their scope. This sequence does not introduce a confirmation requirement.
3. Reuse or improve shared owners. Preserve data, permissions, state, native forms and supported recovery. Remove superseded code after reference checks.
4. Run relevant checks; correct findings before describing the work as complete. Record evidence and limitations in Testing, update the owning documents and keep historical results clearly dated.

## Verification scope

For affected UI, check Light/Dark/System, mobile and desktop, visible keyboard focus/Tab/Escape, associated names/errors, relevant RTL/LTR and long text. Verify actual loading, validation, success, cancellation, unsaved changes and destructive recovery where applicable. Check that font/storage failures do not prevent core tasks. No need to invent loading skeletons or dialogs for synchronous navigation.

Use npm run check:ui, npm run build, relevant isolated PHP tests and existing browser scripts. Broaden testing when shared behavior/security changes or failures justify it. Test data, storage and notifications must be isolated from installed state. Blade compilation checks belong in the disposable environment. No real messages or mutation-heavy installed-data browser runs.

The static UI guard checks token colors, exact duplicate components, conflicting button classes, unsafe/positive-tab-order patterns, own-locale fixed UI catalogs, known retired selectors and canonical entrypoints. These are mechanical checks, not a UX score. Existing Playwright checks cover rendered structure, states, geometry and selected task flows. Visual inspection must state the screens/viewports reviewed; task-flow review must state the actions exercised. No screenshot-diff service, linguistic certification or screen-reader conformance is implied.

Documentation-only work requires link, ownership, conflict and completeness checks; do not rerun application tests or claim new UI verification when no code changed. Git delivery excludes secrets/runtime data/dependencies; commit or push only when requested.

## Multilingual regression priority

Exercise independent English/Turkish fields and manual slugs, Arabic ↔ English/Turkish actual editor direction, unsaved language return, failed navigation/retry, browser history and save-one preservation before cosmetic acceptance. Confirm one searchable language control, real saved coverage, explicit shared/localized settings and native fallback. Use locale-drafts-browser.cjs on disposable data; tab memory is not durable recovery or autosave.
