# Scope

Documentation reviewed against the current source on 2026-10-29. Verification evidence retains its actual dates in [testing](testing.md).

## Approved application
Temp Mail SaaS is an English Laravel 13 / PHP 8.5 application using the stack in [architecture](architecture.md) and the shared [UI system](ui-system.md).

Installation proceeds from database configuration through successful server-side connection verification to administrator creation and completion, then login. Support MySQL, MariaDB, PostgreSQL, and SQLite. Failed or expired verification must not unlock administrator setup. Completion prevents subsequent setup. The installer has no user-facing installation key; access and recovery are owned by [operations](operations.md).

Provide login, public registration, forgot-password, and token-based password reset. Registration creates ordinary members and cannot grant administrator privileges. The first installer-created user is an administrator. Administrator login opens /dashboard; member login opens /account. Preserve the existing authentication pages.

The dashboard shows the authenticated administrator identity and uses responsive left navigation for Dashboard, My account, and Sign out. Only administrators can access it. Account settings are available to both roles; their name, password, email verification, uploaded photo, and ten preset-avatar requirements are owned by [account](account.md). The approved settings refinement separates Profile, Security and Appearance with progressive disclosure while preserving existing account operations.

Every screen uses English copy, Google Fonts with a system fallback, reusable Blade components, keyboard access, associated labels/errors, visible focus, and Light/Dark/System appearance. Appearance and password controls follow [UI system](ui-system.md); acceptance boundaries follow [accessibility](accessibility.md).

## Not yet approved
Temporary inboxes, receiving or forwarding mail, mailbox metrics, subscriptions, billing, additional roles, further management modules, and production deployment are not implied by the application name. Mail credentials, production topology, proxy integration, and delivery configuration remain operator decisions. See [operations](operations.md).

## Blog management — 2026-10-29
The user approved the Blog/Posts/Categories/Tags management menu and Tiptap with slash commands. Canonical requirements are in [blog](blog.md). The later CMS expansion below adds publication workflows; current requirements are canonical in Blog.

## Pages navigation — 2026-10-29

Provide a standalone Pages entry below Blog for administrators, opening an English Pages workspace at /pages. Pages now includes administrator-only draft creation, editing, listing and confirmed deletion using the shared Tiptap editor. Canonical requirements are in [Pages](pages.md). The later CMS expansion below adds publishing and lifecycle workflows.

## Language management — 2026-10-29

Administrator-only language defaults and editable homepage translation catalogs are approved for 30 languages including Hebrew. The user deferred building the homepage. Canonical requirements and the boundary with existing English screens are in [Languages](languages.md).

The approved Language management table includes search, filters, sorting, pagination and individual/bulk availability changes. Canonical behavior and public-selector exclusions are in [Languages](languages.md).

The original request is archived in [Saved prompts](prompts/README.md).

The category-based translation-editor refinement is approved for existing homepage keys only. Search, status filters, provenance, unsaved-change protection and safe reset behavior are owned by [Languages](languages.md); future mailbox/SEO domains remain deferred.

## Images and translated drafts — 2026-10-29

The user approved a shared Images library, linked Post/Page language versions, common and localized covers, and library images inside Tiptap. Canonical media rules are in [Images](images.md); translated draft behavior is in [Content translations](content-translations.md). Existing drafts and English source fields are preserved. The later CMS expansion adds content publication; the homepage remains deferred.

## Multilingual CMS expansion — 2026-10-29

The user approved Posts/Pages data tables, lifecycle publication and scheduling, Trash/Restore, per-language SEO, public previews/rendering, published URL preservation, lightweight revisions and multilingual taxonomy. This supersedes the earlier draft-only exclusions for these modules. Mailbox, billing and homepage implementation remain outside scope. The original CMS request is archived under Saved prompts; canonical behavior will be recorded in Blog, Pages and Content translations.

## CMS functionality completion — 2026-10-29

The critical follow-up approves initial content-language selection, visible translation management, complete Category/Tag Trash/Restore and filtering, and a working featured-image picker from the existing library. The audit/checklist is [CMS completion](cms-completion.md). Content, routes and business behavior must be preserved. Current UX authority is defined below; earlier visual-preservation requirements no longer constrain redesign.

## Current UX reconstruction — 2026-10-29

The user rejected the quality of the previous UX despite working functionality and asked to remove/reconstruct old rules. Task-first UX now owns screen purpose, information architecture and redesign sequence. Shared UI contracts own presentation reuse; Quality separates functional, visual and task-flow evidence. Brand references and earlier premium labels are not acceptance criteria. Existing appearance is a baseline to reassess, not a required design to preserve. Current product capabilities, security/data boundaries and deferred mailbox/homepage scope remain unchanged. This follow-up updates rules/documents; it does not itself implement or validate a new screen design.

## Task-led screen implementation — 2026-10-29

The user now authorizes implementing the reconstructed direction across existing screens, replacing the remaining conventional boxed presentation. Begin with real Dashboard work and Posts discovery, then writing and shared module presentation. Existing data, features, installation/authentication flows and localization/security contracts remain. This supersedes the previous follow-up’s documentation-only delivery scope; it does not authorize mailbox/billing/deployment work.

## Multilingual UX consolidation — 2026-10-30

The latest attached request supersedes all earlier UX visual directions, including Vercel-only. Preserve existing brand/mint/turquoise, stack and features; fix multilingual editor state/direction and unsaved language switching first, then apply shared compact management/form/feedback standards across existing modules and public surfaces. The canonical owners are UX, UI system and Content translations. No application rebuild, new frontend framework, destructive migration or deferred mailbox/homepage feature is authorized.
