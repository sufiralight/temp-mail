# Security

Current boundaries reviewed against the source on 2026-10-29. Approved scope is owned by [scope](scope.md); account acceptance rules by [account](account.md).

## Server-side boundaries
Validate requests, authorize every protected operation on the server, and persist only explicit fields. Escape untrusted Blade output. Blade must not query databases or mutate business state. Hidden links, client-side validation, selected avatar controls, and login destinations do not grant authorization.

All state-changing forms use CSRF protection. Sensitive mutations use route throttling; verified email changes also enforce per-user cooldowns and attempt limits in database state. Dashboard requires auth, auth.session, and the access-dashboard Gate. Only is_admin === true authorizes access. Registration and profile changes cannot mass-assign privilege fields.

Tests must use isolated databases, private fake storage, and fake notifications, never installed state. AppServiceProvider skips installed connection loading under unit tests. Preserve these protections when adding tests.

## Secrets and sessions
Keep credentials, tokens, personal data, and verification codes out of source control, logs, error traces, URLs, documentation examples, and browser persistence. Never flash passwords, database credentials, email-change confirmation passwords, or verification codes back into forms. Use Laravel hashing, encryption, session regeneration, and authentication mechanisms; do not invent cryptography.

The password-reset broker's emailed token URL is the narrowly scoped exception to the no-tokens-in-URLs rule. Reset tokens are hashed, expire, and cannot be reused. Build reset URLs from configured APP_URL, avoid logging reset paths/query strings, and retain no-referrer/no-store responses. Email-change codes remain outside URLs entirely. Reject log/array mail transports for sensitive delivery rather than leaking codes or claiming a message was sent.

Password changes rotate remember tokens and use auth.session to revoke other sessions while retaining the current one. Account changes always resolve the owner from the authenticated session; see [account](account.md) for exact transition and validation rules.

## Installation and private storage
Before completion, installer requests require approved exact network peers, permitted hostnames, and no forwarded headers. The automatic lease and filesystem completion lock are additional state protections, not a substitute for a trusted access path. After completion, the installed marker prevents another setup. Direct/proxy limitations, .env/APP_KEY recovery and backup requirements are owned by [operations](operations.md).

Keep installation state, database files, and uploaded photos outside public/. Authorize image delivery to its owner and allowlist the served MIME type; prevent arbitrary paths and executable uploads. Static project SVG presets do not authorize SVG uploads. Avatar uploads are not re-encoded or malware-scanned; private orphan files from failed cleanup require operator attention.

Email-change transitions lock the user row, commit failed attempts, enforce unique target addresses, and consume successful requests. A request is bound to the original email and password fingerprint. Notifications are synchronous so raw codes do not enter queues. A failure to notify the old address after commit must be reported without undoing the verified change. Full behavior belongs to [account](account.md).

## Browser and deployment
SecurityHeaders supplies a fresh Vite nonce and production CSP. Scripts are limited to self/nonce; styles allow self and fonts.googleapis.com; fonts allow self and fonts.gstatic.com. Constrain objects, frames, base URI and form destinations. Alpine uses its CSP build without unsafe-eval. HMR is excluded from that production policy; never ship public/hot.

Responses receive nosniff, DENY framing, no-referrer, and private/no-store cache headers, including exception responses. Keep these boundaries even where an audit score is lower. Deployment needs HTTPS, secure session cookies, appropriate trusted proxies, APP_DEBUG=false, and public/ as the sole web root. No deployment is authorized by documentation or UI work. Dependency advisories and actual evidence are dated in [testing](testing.md).

Blog management requires auth, auth.session and the manage-blog Gate for every endpoint, including mutations and deletion confirmation. Never infer access from sidebar visibility. BlogPostController supplies the author ID and validates taxonomy kinds; a client cannot change authorship or turn a tag into a category. Transactions cover post/tag updates, and database uniqueness/foreign keys preserve boundaries under competing writes. Used categories cannot be deleted. Canonical behavior is owned by [blog](blog.md).

RichTextDocument validates a constrained, bounded JSON schema rather than trusting HTML. It rejects unsupported nodes, marks and attributes; checks structure/depth/node counts; allowlists URL schemes; and normalizes link metadata. Plain-text fallback input is subject to the same node bounds. Blade escapes stored JSON into a textarea; the editor reads it as data and never evaluates it. No arbitrary HTML publication endpoint is included. Tiptap uses injectCSS=false, the existing production CSP, and local bundled modules; no unsafe-eval or CDN dependency is introduced.

Pages endpoints require auth, auth.session and the access-dashboard Gate, including mutations and deletion confirmation. PageController supplies authorship, accepts only validated fields, and shares RichTextDocument bounds and URL validation with Blog. Page slugs are database-unique and drafts have no public route. See [Pages](pages.md).

Language management requires auth, auth.session and access-dashboard on every route. Only catalog locales and source keys are accepted, English writes are forbidden, and bounded plain-text overrides are saved atomically. Values are escaped in both fields and previews. Neither locale input nor translation text selects arbitrary files, executes markup, changes .env, or grants access. See [Languages](languages.md).

Image library administration and content translation editing require auth, auth.session and access-dashboard for every read and mutation. ImageLibrary decodes bounded raster files and stores only re-encoded WebP variants outside public/. Client paths, uploaded SVG/executables and arbitrary image URLs are never trusted. RichTextDocument accepts only mediaImage IDs and bounded per-use text; ContentImages locks and verifies those IDs before persistence and records restrictive references. File deletion refuses usages and cover foreign keys. Image metadata changes cannot silently overwrite existing use text. Drafts remain private. The CMS public-rendering exception below authorizes only published content and referenced media. See [Images](images.md).

Language availability mutations require the administrator gate, CSRF and request throttling. Deactivation uses a one-use, user-bound server session token expiring after ten minutes; confirmation revalidates live default/active state inside the transaction. Mixed protected selections fail atomically. Availability never grants content access or deletes stored translations.

## CMS publication boundary

All management, preview, revision, taxonomy and lifecycle mutations retain administrator authorization and CSRF. IDs, kinds/locales, query sorts and publication actions are allowlisted server-side. Transactional bulk checks reject the complete selection rather than partially mutating it. Destructive review tokens are actor/kind/selection-bound, expire in ten minutes and are consumed once; live-state failures return to the list with feedback. Existing form version fields detect stale writes against locked records; old clients omitting version retain their existing contract and do not gain optimistic concurrency guarantees.

Public routes require an active locale, a non-trashed published root, a published matching variant and due UTC timestamps. No draft sharing token is created; preview remains administrator-only with noindex. ContentRenderer receives revalidated JSON and escapes text, metadata, captions and link attributes. Public media checks references with bounded relationship queries; revision/draft/Trash references reserve files but grant no public access. Root Trash retains references, and permanent deletion removes only owned relationships. Shared security/no-store headers continue to apply. Canonical overrides accept HTTP(S) only. Historical redirects resolve by content identity to a current public URL and cannot form a stored redirect chain.

The featured-image picker JSON and private thumbnails retain the administrator gate; locale/query/page are bounded and IDs revalidated when saving. PreserveMediaFlash prevents background media/picker requests from consuming navigation feedback; it grants no file permission. Term soft deletion keeps restrictive relationships. Only Trash permits permanent deletion; assigned categories, including dependencies in post Trash, are rejected atomically. Primary and linked slugs share serialized namespace checks.

Locale editor drafts may live transiently in the active document memory under [Content translations](content-translations.md). They are never written to browser storage, URLs or a client log. Enhanced GET/POST uses same-origin authorized existing routes and their CSRF fields; fetched HTML must be the validated matching editor owner/kind and imported scripts are removed. This does not grant access to unpublished content or replace server validation/version checks.
