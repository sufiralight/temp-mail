# Shared UI contracts

## Relationship to UX

[UX](ux.md) determines task, information order and screen composition. This document defines reusable presentation responsibilities. Existing code is a baseline under review; its current appearance has not been established as successful UX. Linear, Vercel, Stripe and WordPress inform usability principles only; do not copy their visual designs.

The user’s 2026-10-30 multilingual UX contract is the only active visual direction. Retire Vercel-only and other mandatory brand recipes. Keep the Temp Mail mint identity, English administration, localized public chrome and existing technical stack. Do not import another brand's assets, add a second CSS framework or replace working interactions for appearance alone. Accessibility and data/security boundaries remain mandatory.

## Tokens and composition

resources/css/app.css owns semantic colors, type, spacing, radii, control sizes and layout values. Light/Dark/System share semantic names: canvas, surface, elevated, ink, secondary, muted, line, panel-line, accent/hover/on-accent, focus, success, warning, error and their backgrounds. Use contrast borders for controls and decorative borders for separation. Literal palette values stay in token declarations.

Google Fonts Inter uses display=swap with system/script/emoji fallback. Size, leading and weight communicate a meaningful hierarchy; no fixed font or spacing recipe proves clarity. Existing numeric values live in CSS and may be revised when justified by a screen brief and verified across affected screens. Do not copy a second table of numeric values into documents.

Administration shares shell geometry, navigation behavior, page-heading semantics and action conventions. Content composition may differ by task. Public reading and guest access have separate shell roles. Mobile must preserve action order and reflow rather than merely shrinking desktop controls. Use logical CSS and explicit locale/direction where relevant.

Panels group related work; they are not the default wrapper for every element. Use whitespace/dividers/typography before adding another card. Match density to reading, editing or scanning; neither uniformly sparse nor uniformly compact is a universal rule. Primary/secondary/danger states must remain understandable in both palettes.

## Existing owners

This is an inventory for reuse, not a claim that every current implementation is visually accepted.

| Responsibility | Owner / contract |
| --- | --- |
| Font/theme/Vite/metadata loading | x-document-head; one nonce-aware source |
| Workspace / guest access | x-layout and x-sidebar; one navigation/current-state/mobile owner |
| Public reading | x-public-layout; explicit locale/direction/meta |
| Heading and actions | x-page-heading; meaningful h1 and optional actions |
| Buttons | x-button primary/secondary/danger; native links for navigation |
| Text/password fields | x-field/x-new-password; labels/help/errors and one visibility enhancement |
| Selects/textareas/choices | native labelled controls and form-input; preserve values, keyboard and native validation |
| Tables and pagination | x-data-table/x-sortable-heading/x-pagination; prepared server data and accessible overflow |
| Feedback | x-notices, semantic statuses and x-submit-status; persistent outcomes and appropriate announcements |
| Generic submission | submitForm only when no specialized owner exists; preserve payload controls and native fallback |
| Content editing | existing rich-text-editor/permalink/publication/SEO/media/locale components |
| Modal interactions | native dialog and the responsible editor/cover owner; label, focus, Escape and return |
| Appearance / tooltips | x-appearance and existing control/password owners; meaningful names and keyboard behavior |
| Disclosure / subnavigation | native details/summary and real links with current state |

Change the responsible owner when its responsibility remains the same. Share appearance without merging unrelated business rules. Add a component only for a demonstrated reusable responsibility; do not prebuild an unused catalog. Current native controls, publication/translation rules, media permissions, revision behavior and destructive protections remain owned by feature documents.

## Replacement and verification

Remove superseded styles/components only after checking references and replacing required behavior. Do not keep a legacy theme plus a new override layer, or delete working code merely because it predates a redesign. Preserve historical evidence with its date and status rather than treating old screenshots as mandatory targets.

Use [Quality](quality.md) for independent functional, visual and task-flow verification. Tokens, source lint and screenshots support review; they do not establish usability or accessibility conformance by themselves.

## Existing content studio baseline — 2026-10-30

The current implementation uses open sections, typographic headings, lifecycle dots and row separators instead of enclosing every task in a card. The shared shell, logical spacing, semantic palettes and responsive navigation apply across existing screens. Dashboard provides real post counts and recent work; collection search precedes a native Filters & sorting disclosure. Editors place writing before excerpt and language coverage, with secondary settings alongside on wide screens. This implementation is a reviewable baseline, not a claim of user acceptance.

## Current shared standard

Use one primary action per context, aligned headers, compact readable density, restrained mint/turquoise accents, semantic theme tokens and modest control radii. Avoid redundant language controls, decorative actions and cards around every field. Shared headers, fields, tabs, tables, pagination, dialogs, feedback, empty/loading states, sidebar and editor toolbar have one responsible owner. Native links/forms remain the fallback; Alpine enhances real task flows without a new framework. Public content shares identity and tokens with its own reading composition.
