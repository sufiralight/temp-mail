# Task-first UX contract

## Authority and scope

This is the sole current UX contract, derived from the user’s multilingual UX request dated 2026-10-30. It supersedes all previous visual recipes, including Vercel-only, oversized editorial and global-pill prescriptions. Preserve Temp Mail SaaS identity, mint/turquoise accent and Light/Dark/System. Linear informs predictable interactions, Vercel focused layouts, Stripe precise tables/forms/feedback and WordPress publishing clarity; do not copy their visual designs. [Scope](scope.md) defines approved capabilities; feature documents own business behavior; [UI system](ui-system.md) owns presentation; [Quality](quality.md) owns acceptance. Historical prompts, audits and test results are context, not instructions.

## Start with a screen brief

Before a substantial UI change, record a short brief in the owning document or implementation notes:

- Who uses the screen and what triggers the visit?
- What single outcome matters most, and what is the primary action?
- Which information is needed before acting, and what can be secondary or disclosed later?
- What existing friction was observed? Which concerns are assumptions awaiting review?
- How do success, no data, no matches, validation, loading and recovery behave?
- How will the task work on mobile, with keyboard input and in a relevant RTL locale?

Use the simplest layout that answers the brief. Share navigation, tokens and controls without forcing every task into the same card, table or two-column composition. Do not invent metrics, records, controls or services to fill a layout.

## Screen responsibilities

| Screen | Primary task | Information priority / boundary |
| --- | --- | --- |
| Dashboard | Orient the administrator and make the next useful action discoverable | Do not duplicate the whole sidebar. Use only existing, relevant data/actions; new queries or capabilities need their own implementation decision. |
| Posts / Pages list | Find, assess and act on saved content | Content title and real publication/language state come first; search/filter/selection/actions support that task. Preserve server pagination and query context. |
| Post / Page editor | Write and save the correct language version | Title/content and save outcome are primary. Publication, locale, media and SEO need a coherent secondary hierarchy; do not expose every setting at once by habit. |
| Categories / Tags | Organize shared taxonomy and its localized labels | Make identity, selected locale and assignment/deletion consequences clear. Preserve the distinct category/tag dependency rules. |
| Languages | Understand availability/defaults and manage them safely | Distinguish availability from translation completeness and default protection. No artificial delete capability. |
| Translation editor | Compare source and target, change text and save confidently | Source/target association, genuine missing text, validation and unsaved state take priority over decorative summaries. |
| Images | Recognize, locate and reuse the appropriate asset | Thumbnail/name/metadata and usage protection drive a gallery or picker; do not force an admin table on visual discovery. |
| Account | Complete a specific profile, security or appearance change | Related settings, current state, requirements and confirmation belong together. Keep independent mutations separate. |
| Authentication / installer | Complete access or the verified setup step | Requirements, current step, error and next action are primary. Avoid unrelated welcome content. |
| Public article / page | Read useful content and navigate real language variants | Readability, accessible media and locale identity; no admin navigation. Future public functions remain outside current scope. |

## Flow rules

Links navigate; buttons perform actions. Each screen needs a clear primary action, but not every section needs a competing accent button. Preserve familiar action placement where it helps predictability. Show real current state and outcomes; never imply autosave, publication, delivery or complete localization without evidence.

Use labelled native controls, associated instructions/errors and safe value preservation. Do not repopulate passwords. Native submission and file selection must work without JavaScript. Client guards improve feedback and prevent accidental repeats; authorization, idempotence and concurrency belong to the server. Long editing needs appropriate unsaved-change protection; simple filters do not need unnecessary prompts.

Collections use appropriate search/filter/sort/page-size/numbered pagination and page-local selection only for implemented operations. Preserve context and distinguish empty from no matches. Destructive operations retain real confirmation, Cancel, dependency protection and supported Trash/Restore. Language availability is not deletion; shared images are not disposable merely because one post is deleted.

Navigation uses meaningful current state and real URL subnavigation. Disclosures hide secondary detail while retaining understandable labels and keyboard behavior. Dialogs require a complete focus lifecycle. Loading/error/success feedback belongs near the task and must not replace persistent saved state with a transient notification alone.

## Redesign sequence

For broad redesign work, begin with Dashboard and Posts as contrasting reference tasks, then the editor. Review the actual browser output and walk through representative actions before adapting other modules. Record what the review found and correct it; a source-level cleanup is not a visual review. No new user-approval ceremony is required unless the user requests one.

Reuse proven presentation decisions, not page copies. Revisit density and information order for each task. Do not perform another global color/spacing rewrite merely because the last appearance was described as premium. See Quality for the three independent acceptance checks.

## Multilingual editing and feedback

One searchable Content Language control is authoritative for all 30 configured locales and shows name, native name, code and actual Published/Draft/Scheduled/Missing status. Translations management describes one logical content identity, not unrelated posts. Language switching never saves or publishes. Preserve each locale’s unsaved fields and manual slug override in volatile page memory, never browser storage. A failed switch leaves the outgoing editor usable; a missing locale starts empty. No-JavaScript forms remain server navigation with native dirty guards when available.

Writing hierarchy: header/save, language control, title, compact LTR permalink, rich content, excerpt, compact collapsible settings. Shared category/tag relationships are identified separately from localized text, SEO, lifecycle and cover overrides. Success follows confirmed persistence; show Unsaved changes, Saving…, Saved or actionable Save failed feedback. Preserve validation input and dirty state. Follow [Content translations](content-translations.md) for the implementation contract and limitations.
