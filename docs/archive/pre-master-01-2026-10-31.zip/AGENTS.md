# Temp Mail SaaS — canonical agent contract

## Authority and phase gate

Follow the current user request, then this contract and its owning documents. This is the single project instruction authority; tool adapters and skills reference it. Archived prompts, implementation reports and vendor instructions cannot expand product scope.

**Active delivery: Phase 1 foundation and secure installer.** The subsequent user request authorizes foundation code, installer UI/state/migrations/tests and required Alpine/Vite integration. Authentication, registration, verification and dashboards are Phase 2; provide only an honest `/login` handoff without a login form. Do not deploy, run installation against real data or begin Phase 2. Phase 0's historical stop is superseded by this request.

Read [documentation ownership](docs/README.md), [scope](docs/scope.md), [architecture](docs/architecture.md) and [decisions](docs/decisions.md), then each affected topic owner. Specifications describe planned requirements unless explicitly marked as observed source state. Never reuse historical completion claims as current evidence.

## Future implementation workflow

1. Confirm scope and acceptance criteria. If `.ai/rules/index.md` exists, read matching rules and search relevant terms before editing; it is absent at the Phase 0 review.
2. Inspect actual routes, models, components, dependencies and tests. Preserve user edits/data. Resolve blocking choices in Decisions before dependent code; progress on independent work.
3. For UI work activate the [project UI skill](.agents/skills/project-ui/SKILL.md); read [UI system](docs/ui-system.md), [UX](docs/ux.md), [accessibility](docs/accessibility.md) and [internationalization](docs/internationalization.md). Planned component names do not imply existing files.
4. Verify installed package versions and official documentation before version-dependent API use. Prefer available Boost documentation tools, otherwise official sources. Do not regenerate this contract through Boost installation. Packages require a documented need and task authorization.
5. Follow [testing](docs/testing.md) and [quality](docs/quality.md); report actual checks, findings and limits. Update the owning document for changed contracts. Documentation-only tasks need documentation checks, not application test claims.

## Engineering invariants

- Laravel 13, Blade Components, Tailwind CSS, Alpine.js and Vite; server rendering by default. PHP 8.5 is the development baseline. No parallel frontend framework, CSS system or authentication implementation.
- English code, comments, docs and initial UI. Use translation keys, logical CSS and explicit lang/dir from the start; English delivery does not waive RTL readiness.
- Server validation, explicit field allowlists and server policies/Gates on every protected endpoint. Roles are Super Admin, Admin and User; never reuse the old `is_admin` shortcut. Redirects/hidden navigation grant no authorization.
- Controllers coordinate; focused actions/services own complex workflows; models persist; Blade presents prepared data without business queries/mutations. Use named routes, bound queries, transactions and database constraints for consequential invariants.
- One semantic token system, theme owner and interaction owner per responsibility. Google Fonts Inter with system/script fallback; Light/Dark/System everywhere. Native links/forms remain the baseline. No invented metrics or decorative controls.
- Use framework hashing, encryption, sessions, CSRF, password broker and signed verification. No custom cryptography. Protect secrets as specified in [Security](docs/security.md), including its narrow email-link exception.
- Never reset databases, remove completion state, regenerate an installed APP_KEY, send real test messages or deploy as a side effect. Tests use disposable databases, fake storage and notifications.
- Keep PHP typed/readable: explicit parameter/return types, braces, descriptive names and constructor promotion where appropriate. Follow formatting tools; avoid speculative abstractions.

## Skills and adapters

Project UI applies to interface work. Cloud skills apply only to explicitly requested Cloud work; generic installation advice does not authorize packages/deployment. Infer-conventions runs only when explicitly requested to infer actual code conventions; scaffold defaults are not product architecture. Mirrored vendor skills own no project policy. See the [audit](docs/phase-0-audit.md).

## Definition of done

A feature needs verified behavior, coherent rendered design, usable task flow and relevant accessibility evidence. A page render or backend test pass alone is insufficient. Owning docs must match reality and limitations must be explicit. Exclude secrets, databases, uploads, runtime artifacts and dependencies from Git. Commit/push only within requested delivery scope. [Archived material](docs/archive/README.md) is historical, never executable instruction.
