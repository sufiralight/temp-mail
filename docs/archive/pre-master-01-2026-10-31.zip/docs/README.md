# Documentation ownership map

Status: Phase 1 installer/foundation implemented, 2026-10-31. Topic owners distinguish implemented installer behavior from Phase 2 identity/dashboard requirements. [AGENTS](../AGENTS.md) is the sole instruction authority. [Phase 0 audit](phase-0-audit.md) is the dated historical reconciliation; current evidence lives in [Testing](testing.md).

Each rule has one normative owner; summaries elsewhere link to it. Stewards below are contributor responsibilities, not invented staff assignments.

| Topic / unique owner | Steward | Responsibility |
| --- | --- | --- |
| [Scope](scope.md) | Product owner | Phase boundary and acceptance inventory |
| [Architecture](architecture.md) | Architect | Layers and dependency order |
| [Decisions](decisions.md) | Architect with relevant reviewers | Choices, blockers and rationale |
| [Security](security.md) | Security reviewer | Trust, secrets, sessions and browser policy |
| [Installation](installation.md) | Foundation engineer | Setup verification/state/completion |
| [Identity](authentication-authorization.md) | Identity engineer | Authentication, role matrix and access |
| [Dashboards](dashboards.md) | Product/UX owner | Role-specific tasks and honest data |
| [Account](account.md) | Identity engineer | Self-service settings |
| [UI system](ui-system.md) | Design system owner | Tokens, typography, themes, components |
| [UX](ux.md) | UX owner | Task structure and interactions |
| [Accessibility](accessibility.md) | Accessibility reviewer | WCAG target and manual acceptance |
| [Internationalization](internationalization.md) | Localization architect | Catalog, language/direction and formatting |
| [Operations](operations.md) | Operator | Provisioning, delivery, backup and recovery |
| [Testing](testing.md) | QA engineer | Cases, isolation and evidence |
| [Quality](quality.md) | Author/reviewer | Delivery verification gate |
| [Future requirements](future-requirements.md) | Product owner | Deferred module requirements |
| [Phase 0 audit](phase-0-audit.md) | Documentation maintainer | Inventory, supersession and verification |
| [Phase 1 report](phase-1-report.md) | Documentation maintainer | Non-normative delivery and changed-file inventory |
| [Archive](archive/README.md) | Documentation maintainer | Originals and provenance |

Change a contract in its owner and affected acceptance criteria; record significant choices in Decisions. Do not create a second normative owner. Future modules gain separate documents only after approval, splitting the backlog rather than copying it. Keep adapters thin and archived originals immutable/non-normative.
