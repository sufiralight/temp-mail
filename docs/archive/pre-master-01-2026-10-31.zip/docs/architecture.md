# Rebuild architecture

Status: Phase 1 foundation/installer implemented on 2026-10-31; identity and dashboards are Phase 2. The scaffold welcome was removed after reference checks. `/` dispatches to setup or the honest login handoff. Shared Blade installer components, semantic CSS/Inter, Alpine CSP and Vite are integrated; no authentication form or dashboard endpoint exists yet.

| Layer | Responsibility |
| --- | --- |
| Routes/middleware | Install state, authentication, verification and endpoint access |
| Form Requests | Server validation, allowlisted typed inputs, mutation authorization |
| Controllers | Request/action/response coordination and prepared view data |
| Focused actions/services | Complex installer/identity workflows and concurrency |
| Models/database | Persistence, relationships, uniqueness and durable invariants |
| Policies/Gates | Explicit role capabilities and ownership; deny unknown capabilities |
| Blade Components | Semantic server-rendered presentation |
| Tailwind/shared CSS | One semantic token and responsive styling system |
| Alpine CSP | Small enhancements, one bundled initialization/interaction owner |
| Vite | Local Laravel/Tailwind asset integration |

Use conventional Laravel structure and injection. Add focused classes for demonstrated complexity; avoid generic repositories, module/plugin systems and SPA routers. Proposed responsibilities do not require prebuilding all abstractions. No business queries or mutations in Blade. Use complete discoverable Tailwind classes.

## Runtime and persistence

Laravel 13 and PHP 8.5 development baseline; composer.json currently permits PHP ^8.3, not a tested support promise. Confirm locked versions, PHP extensions and Node/Vite compatibility at implementation. Historical version tables do not select new packages.

Installer boots using encrypted file sessions, file cache and synchronous queue configuration without application DB queries. D-02 is resolved for one persistent host. Entry/handoff routes fail closed until authoritative completion is valid; an outage never reopens setup. Future database-dependent routes must use the same installation boundary.

Use one session identity and explicit capabilities, not duplicated authentication systems. Admin/user shells share tokens/components with distinct navigation. Settings always resolve the current owner.

Related writes use transactions and constraints. A database transaction cannot alone make database/filesystem completion atomic; use checkpoints and recovery in [Installation](installation.md). Send network notifications outside database locks with explicit failure outcomes. No migration/seeder creates default privileged credentials.

[Security](security.md), [Identity](authentication-authorization.md), [UI system](ui-system.md), [Internationalization](internationalization.md) and [Operations](operations.md) own cross-cutting contracts. [Decisions](decisions.md) owns unresolved choices. Deferred module schemas/class names remain undecided; [Future requirements](future-requirements.md) preserves invariants.

## Implemented owners

`InstallationController` coordinates validated steps; `InstallationRequest` allowlists fields; `InstallationAccess` owns setup transport/session guards. `Installer` owns transitions, checkpoints, hashing and completion; `InstallationStore` owns encrypted atomic state and OS locks; `DatabaseProbe` owns bounded candidate connections/empty-target checks and purging; `Requirements` checks the live runtime. Operator commands issue grants/resume or verify/reseal completion. `AppServiceProvider` sets bootstrap stores and registers a lazy installed connection after configuration defaults: the config repository contains only an opaque installed driver, not decrypted credentials. The resolver decrypts into a Connection object only when used, preventing config:cache from persisting the installed password. `SecurityHeaders` and exception handlers protect normal/error responses without rendering or reporting raw installer exceptions.

`Role` and an additive migration prepare User/Super Admin/Admin persistence. `users.role` defaults to user and is excluded from mass assignment; receipts bind one installation to its initial administrator. No web role editor or authorization capabilities beyond installer ownership are implemented. PHP feature/independent-process tests and an isolated Chrome script cover installer behavior; see Testing for actual evidence.
