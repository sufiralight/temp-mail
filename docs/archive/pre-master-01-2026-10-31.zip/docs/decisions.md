# Architecture decision register

Status: 2026-10-31 Phase 1 installer. The Phase 1 resolutions below supersede the earlier open-decision descriptions for the current delivery. Historical ADRs/versions remain in the [archive](archive/README.md), not automatic requirements.

## Accepted foundation

- A-01: Laravel 13, Blade SSR/components, Tailwind, Alpine and Vite; PHP 8.5 development baseline. One token/theme/interaction system, planned Alpine CSP distribution. No parallel SPA/UI framework.
- A-02: English initially, semantic translation keys and the 30-code RTL-ready foundation. Google Fonts Inter with fallback; Light/Dark/System. Theme preference is device-local, not synchronized account data.
- A-03: Three explicit role values and unverified installer-created Super Admin; two protected dashboard destinations are the Phase 2 target in [Identity](authentication-authorization.md). No `is_admin`, public role assignment or blanket privileged bypass.
- A-04 (Phase 2 identity target): mandatory verification for dashboards, with verification/resend/logout/self-settings recovery before verification. Photos, code-based email changes and role-management UI stay deferred.
- A-05: Database probe is non-destructive; new install requires an empty approved target, session/settings-bound proof and durable completion. No automatic reset or reinstall after outage. Specific topology/storage mechanisms remain below.
- A-06 (historical Phase 0 boundary): that delivery changed documentation/instruction adapters only and preserved originals in the hash-verified archive. The subsequent Phase 1 request now authorizes the installer implementation; the archive remains immutable.

## Decision history and dependency gates

The table records original questions. Consult the Phase 1 resolutions below for current status: D-01/D-02 resolved for installer baseline; D-04/D-07/D-08 resolved for the installer subset. Identity mail/provisioning/localization and remaining public-account choices are Phase 2/future gates.

| ID | Decision / recommended direction | Must resolve before | Required review/evidence |
| --- | --- | --- | --- |
| D-01 | Production DB engines/versions and compatibility matrix. Candidate MySQL/MariaDB/PostgreSQL/SQLite; support only explicitly selected and tested engines | Installer driver UI, schema and DB-specific tests | Product/operator target, extensions/TLS, live integration matrix; no connector-only claims |
| D-02 | Hosting topology, installer access gate, encrypted config owner, durable proof/checkpoints/locks and pre-DB session/cache. Recommend explicit single-host persistent baseline only if hosting permits it; otherwise shared durable state | Installer/foundation state implementation | Threat model, proxy policy, lock/crash/recovery design; APP_KEY provisioning and config-cache behavior |
| D-03 | Identity mail transport/sender, canonical HTTPS URL, timeout/retry and operational delivery mode. Prefer simple synchronous delivery initially unless measured need for durable queues | Reset/verification delivery and release | No secret logging/queue leakage; safe failure/retry; real staging delivery rehearsal |
| D-04 | Framework-native identity implementation or narrowly justified maintained package; exact Alpine CSP/runtime/Node versions and browser floor | Dependency changes and identity/UI integration | Inspect lockfiles, official compatibility/API review; avoid starter-kit framework substitution |
| D-05 | Operator-only Admin provisioning and future role transitions; preservation/recovery of last Super Admin | Any role provisioning beyond installer | No default credentials, no public endpoint, audit/recent-auth/concurrency design; UI remains excluded |
| D-06 | Regional/script locale metadata, future public URL/locale negotiation and translated release policy | Additional language or public CMS phase | Native review, canonical/hreflang strategy; Phase 1 stays English/unprefixed |
| D-07 | Password hasher and non-truncating maximum; enforceable cross-session revocation strategy | Password registration/change/reset code | Unicode/long-password/hash limits, remember-me and multi-browser revocation tests |
| D-08 | Email normalization, case uniqueness/collation and enumeration-resistant duplicate registration behavior | Registration schema/validation | DB uniqueness/races and consistent login/reset normalization; neutral public outcomes |

D-05 is not a reason to build user management now. If operator provisioning is not delivered, record it as unavailable rather than silently adding a web role editor. D-06 does not block English foundation work. No open decision is silently resolved by copying an old class/table/lease duration.

## Source and API reference review

## Phase 1 decisions — 2026-10-31

- D-01 resolved for this release: SQLite is the enabled/tested baseline (SQLite >= 3.26). MySQL/MariaDB/PostgreSQL adapters are implemented but opt-in through INSTALLATION_DRIVERS and require the corresponding PDO extension and isolated live-engine qualification before production claims. Defaults do not expose unqualified engines. No remote database server is created by setup.
- D-02 resolved: one application host with persistent private storage and OS advisory file locks; no Octane, ephemeral replicas or shared proxy installation support. HTTPS direct access in production, loopback HTTP only for local development. Canonical Host required; forwarded headers rejected for setup. Operator CLI generates a 256-bit one-use 15-minute grant, exchanged for a regenerated, 20-minute owned session. Credentials/state are Laravel-encrypted private files; provisioned and completion sentinels fail closed. Recovery after migration begins is an explicit operator-assisted same-target resume, never a new installation. APP_KEY is never changed. File sessions/cache avoid pre-DB dependencies; persisted connection overrides environment and cached DB settings at request boot.
- D-04 partially resolved: Laravel 13.39/PHP 8.5.12, Node 24.22.1; install only bundled Alpine CSP alongside existing Vite/Tailwind. No authentication package needed in this phase. Full browser support remains evidence-limited.
- D-07 installer policy resolved: Argon2id, 12–128 Unicode characters, no composition rules or silent truncation; future session revocation belongs to Phase 2.
- D-08 installer normalization resolved: trim/lowercase a valid email (max 255), database uniqueness; public registration duplicate/enumeration policy remains Phase 2.
- D-03/D-05/D-06 remain deferred with their dependent identity/operator/localization modules. Their earlier gates do not block an installer-only delivery. The new user request supersedes the old full-identity Phase 1 boundary. `docs/ui-system.md` is canonical; no duplicate design-system.md is created.

Official Laravel 13 database connections/schema/migrations, encryption, CSRF and Alpine CSP documentation reviewed before implementation. Code must not report raw connector exceptions or enable arbitrary migration paths through a request.

Phase 0 source snapshot, before Phase 1: Laravel ^13.17, PHP ^8.3, Tailwind ^4, Vite ^8 and Laravel Vite plugin ^3.1 were declared, Boost was present and Alpine was absent. No package was installed in that documentation-only phase. Phase 1 installs Alpine CSP and commits a new npm lockfile on a future Git delivery; exact verified runtime/locked versions are in [Testing](testing.md).

Official framework references consulted for the specification: [session authentication](https://laravel.com/docs/13.x/authentication), [email verification](https://laravel.com/docs/13.x/verification), [password reset](https://laravel.com/docs/13.x/passwords), [Alpine CSP](https://alpinejs.dev/advanced/csp) and [WCAG 2.2](https://www.w3.org/TR/WCAG22/). Recheck installed-version APIs when implementing; these links do not certify the proposed installer or security controls. No framework method signatures or historical test counts are treated as new evidence.
