# Preserved future requirements

Status: backlog only. None of these modules is approved for immediate Phase 1 implementation or claimed implemented. [Scope](scope.md) is the sole approval boundary. Original detail survives in the [archive](archive/README.md); old code/class/table/route names and numeric limits require new review.

## CMS and multilingual content

Preserve one logical Post/Page/taxonomy identity with independent localized text, slug, SEO and lifecycle. Do not create 30 unrelated records or count fallback as completed content. Choose normalized schema/root publication rules in a future ADR; the old primary-root global gate is not automatically retained. Support safe Draft/Published/Scheduled and explicit Trash/Restore, preview/revisions and published URL preservation without redirect chains when approved.

Retain server-driven search, bounded pagination/sort/filter, real counts and explicit current-page selection; authorize/revalidate the complete selection atomically. Do not silently act on hidden records. Category/tag removal must preserve posts and protect dependencies, including trashed content. Restore revisions as drafts; choose revision retention based on requirements rather than blindly copying 20.

Editors need one active locale, independent title/slug/body/excerpt/SEO/manual-slug/dirty state, correct actual editor RTL lifecycle and protection for unsaved work when switching. Saving one locale cannot overwrite another. Missing translations start empty and cannot be published via fallback. If volatile in-tab drafts are selected, disclose crash/reload loss; no secret browser persistence. Do not preselect Tiptap/version, fetch-router or old JSON schema during Phase 1.

Rich documents must have bounded structure/depth/size and allowlisted nodes/attributes/URL protocols, escaped server rendering and a stored-XSS threat model. Public content/media must require actual active/published/due/non-trashed authorization. Drafts/revisions do not make media public. Future canonical/hreflang/sitemap only list valid public equivalents. Scheduled publication requires a real idempotent execution path/timezone policy, not just a datetime field. No public draft-sharing tokens, SEO scoring or autosave implied.

## Images and future profile media

One reusable media library, private storage, bounded validated raster decoding/re-encoding, randomized immutable paths and authorized delivery. Define current processing/type/size limits at approval time; old workstation GD/2MiB constraints are historical. Reject uploaded SVG/executables and arbitrary remote URLs unless separately threat-modeled.

Track references transactionally; shared files survive content Trash/deletion while other uses/revisions need them. Show genuine usage/deletion consequences. Per-use alt/decorative/caption state is explicit and cannot be silently rewritten by library metadata edits. Accessible picker supports actual search/pagination/single selection/confirm/cancel/focus return. Original SVG avatar presets do not authorize SVG uploads. Cloud storage, malware scanning, orphan cleanup and EXIF handling need explicit decisions.

## Languages management

Retain the [Internationalization](internationalization.md) catalog. English is immutable fixed-text source; separate bundled/customized/missing/fallback provenance and exclude fallback from coverage. Default must remain active and at least one active language must survive; deactivation preserves translations and cannot grant publication access. Bound locale/key input, escape text and preserve actual placeholder semantics. Atomic saving, reset meaning, dirty tracking and clear source/target directions remain valuable requirements.

Future dynamic content translations, fixed UI catalogs and administrator-editable overrides stay separate. Do not retain eight old homepage keys or old category storage as new-project schema assumptions. Language release requires translation/native-script review; a key inventory is not linguistic certification.

## Temp Mail Engine

No mailboxes, domains, receiving/forwarding, refresh transport, message renderer or retention policy is designed/implemented. Before approval define abuse controls/rate limits, mailbox ownership/access secrets, message/attachment isolation, untrusted email HTML sanitization, remote-content/tracking policy, retention/deletion and operational inbound-mail topology. Safe copy feedback/real refresh/empty/error states must reflect actual capability. Never render arbitrary email HTML as trusted application content.

## Subscriptions and billing

No plans, entitlements, payment provider, checkout, webhook or invoice model is selected. Future approval must define authorization/entitlement boundaries, idempotent signed webhook processing, replay protection, money/currency precision, lifecycle/reconciliation, refunds and provider-hosted sensitive payment handling. Avoid fake subscription metrics now.

## Expansion dependencies

All future modules depend on accepted Phase 1 identity/security/design/accessibility foundations and separate scoped ADRs/tests. CMS translations depend on locale/public URL decisions; media integration depends on image permissions/reference rules; schedules depend on operator execution; billing depends on provider and reconciliation decisions. Preserve invariants, then redesign implementation for this source rather than resurrect old migrations, fixtures or completion claims.
