# Secure installation — implemented Phase 1

Implemented 2026-10-31. [Security](security.md) owns common controls; [Operations](operations.md) owns provisioning/backup/recovery. Authentication and dashboards remain Phase 2. Only an honest `/login` information page exists; it has no fake form and never signs in the installer.

## Supported deployment

Single application host, persistent private disk, ordinary PHP request workers and OS advisory file locks. Ephemeral/multi-replica/Octane deployments are not supported by this installer. Production setup requires direct HTTPS with canonical APP_URL host. HTTP is allowed only on loopback in local/testing environments. Setup rejects Forwarded, X-Forwarded-For/Host/Proto and X-Real-IP; a proxy is not implicitly trusted. Use direct access or a restricted tunnel; a reverse-proxy installation requires a separately reviewed design.

Host and port must match APP_URL exactly: localhost is not implicitly equivalent to 127.0.0.1. The reported local IP-alias block is documented with the approved direct access method in [Operations](operations.md#local-installer-address-and-blocked-access-diagnosis). Access errors now distinguish host, port and forwarded headers; X-Forwarded-Port/Prefix are explicitly rejected too. Loopback-only local diagnostics reveal names/categories, never forwarded values or secrets. Recovery links use validated configuration, never request Host or forwarded input. No proxy trust or authorization exemption was added.

SQLite >= 3.26 is the enabled and integration-tested baseline. MySQL/MariaDB/PostgreSQL connectors are implemented but opt-in, not live-engine-qualified here. INSTALLATION_DRIVERS controls availability and missing PDO extensions suppress a driver. INSTALLATION_DATABASE_HOSTS allowlists server destinations; ports are restricted to configured installation MySQL/PostgreSQL ports. No arbitrary DSN, URL, path or options input. Remote DB servers/databases/users must already exist. Qualify remote engine version, privileges, TLS and migration/recovery behavior before enabling it in production. The current runtime lacks pdo_pgsql, despite having the separate pgsql extension.

## Operator authorization

Privately provision stable APP_KEY and writable private/runtime directories, then run `php artisan install:authorize`. It prints a random 256-bit one-use credential to the operator terminal; do not log/share that output. Only its SHA-256 digest is persisted, inside encrypted state. It expires after 15 minutes. No default secret, query-string grant or localhost-only takeover protection.

GET /install initially shows only the authorization form. POST /install/authorize exchanges the credential for a regenerated encrypted-file session with a random server-generated ownership secret. State stores only its hash. The owned authorization lasts 20 minutes; the consumed credential cannot be replayed. A live owned session blocks another CLI grant. Issuing a replacement before migration clears obsolete proof/pending administrator state, never selected database data. Rate limits are 20 requests/minute per peer, 10/minute per session and 5 grant exchanges/minute per peer. All mutations retain Laravel request-forgery protection.

## Routes and state transitions

| Method / route | Result / server guard |
| --- | --- |
| GET /install | Authorization, then actual requirements and next action |
| POST /install/authorize | One-use grant exchange |
| GET /install/database | Owned session and passing requirements |
| POST /install/database/test | Invalidate old proof, validate/probe fresh candidate, then verified state |
| GET /install/admin | Valid ownership and unexpired database proof |
| POST /install/admin | Validate/hash pending administrator; no user exists yet |
| GET /install/complete | Owned, verified, ready state and review |
| POST /install/complete | Locked revalidation, migrations, administrator/receipt and completion |
| GET /login | Completed-installation information only |

Persistent phases: authorized → verified → ready → migrating → schema_ready → admin_saved → complete. Failures after migration begins enter recovery; unknown/corrupt/missing provisioned state fails closed. Proof lasts 10 minutes and binds the exact encrypted connection and owning session. Any DB test submission, even invalid input, clears prior proof/pending administrator first. Expiry or changed settings cannot unlock administrator creation. Moving back alone does not mutate state.

## Requirements and connection test

Report actual PHP version (8.3 minimum, verified development 8.5), Laravel-required extensions, Argon2id, valid encryption key, configured session/cache/storage and bootstrap-cache writability, canonical URL, private state path and enabled PDO drivers. Production URL must be HTTPS and debug disabled. Missing APP_KEY returns safe remediation before session boot. Critical failures block continuation.

Probe uses a temporary named Laravel connection, SELECT 1, schema/table/view inspection and an empty-target requirement. SQLite also checks version and private file/directory writability. It never runs migrations or writes tables. PDO connections are purged on exit, database exceptions are replaced by safe messages without previous exceptions, and query logging is disabled. Server connection timeout is five seconds; PostgreSQL DSN adds connect_timeout. Required DDL privileges are exercised at finalization, not proven by SELECT; a failed migration enters controlled recovery. Live remote permission/TLS qualification remains a release prerequisite.

SQLite is a fixed private file; user-supplied SQLite paths are excluded. Existing tables/views cause rejection with no changes. Database credentials/passwords never enter flash input, HTML values, logs, URLs, plaintext sessions or browser storage. Name/email safe values survive validation. All UI text is English translation resources; essential forms work without JavaScript.

## Persistence, completion and recovery

`InstallationStore` keeps state.enc (Laravel encrypted with existing APP_KEY), provisioned sentinel, setup.lock and installed marker outside public/. State includes connection, proof/ownership expiries, installation UUID and temporarily the pending Argon2id password hash. POSIX directory/file creation uses 0700/0600; Windows requires operator ACLs. File writes flush/fsync to a random temporary file and atomically rename. No .env write, APP_KEY generation or DB_URL import occurs. The provider registers an opaque installed driver after cached/environment configuration; only its lazy connection resolver decrypts credentials into a runtime Connection. Therefore config:cache does not persist the installed password. Tests skip real installed state and independently verify cached/restarted selection.

Completion obtains a nonblocking exclusive OS lock, rechecks ownership/proof/requirements and fresh-target safety, then checkpoints before migration. Only repository migrations run. An additive foundation migration adds users.role (default user), installation_receipts and application_settings. Super Admin, receipt and locale/appearance defaults commit in one DB transaction. A matching receipt allows a retry to preserve the original account; foreign users/settings/receipts are rejected. Pending password hash is removed from complete state. Completion closes every install route, invalidates the setup session and redirects to /login. Initial Super Admin is unverified.

The filesystem/DDL/database are not one transaction. A caught partial failure preserves state and blocks normal continuation. `php artisan install:authorize --resume` is an explicit operator procedure after backup/inspection: only the original encrypted target with the complete expected tables, role column and migration history can resume. It never retargets, reruns partial DDL blindly or overwrites a committed administrator. Partial schemas require operator repair first.

If the account/receipt committed but completion files disagree (including a process killed between writes), `php artisan install:seal` verifies original installation UUID, exact schema/migration history and receipt's Super Admin before reconciling completion files. It creates no user and runs no migration. Missing/corrupt encrypted state requires restoration of matching backups and original key, not reset/reinstall. An outage or missing marker never makes complete state publicly installable. No public reinstall action exists.

Filesystem durability depends on the host/filesystem and backups; fsync/atomic rename are not a substitute for power-loss recovery rehearsal. See [Testing](testing.md) for executed evidence and gaps.
