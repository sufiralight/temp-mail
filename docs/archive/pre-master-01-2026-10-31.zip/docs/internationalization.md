# Internationalization foundation

Status: English-only Phase 1 with 30-language architectural readiness. No Languages UI, public locale selector, automatic translation or multilingual CMS is approved. [Scope](scope.md) owns release boundaries.

## Catalog and text ownership

Retain these planned locale codes from the reviewed requirements:

`en, ar, bn, zh, cs, nl, fr, de, el, he, hi, id, it, ja, ko, ms, fa, pl, pt, ro, ru, es, sw, sv, ta, th, tr, uk, ur, vi`.

Arabic (ar), Hebrew (he), Persian (fa) and Urdu (ur) are RTL; the remaining catalog entries are LTR. One future allowlisted config catalog owns code, English/native display name and direction. Regional/script variants, particularly zh and pt, need localization review before their release; do not invent a regional variant now. Never derive files, views, redirects or DB identifiers from arbitrary locale input.

English is the fixed UI source. Use stable semantic Laravel translation keys for visible copy, validation and notifications from the first feature. Initial resources contain English only; do not generate 29 empty/fake catalogs or claim translations exist. Keep fixed interface resources separate from future dynamic CMS translations and administrator overrides. Missing fixed text may fall back explicitly to English but does not count as completed translation. Missing future dynamic content must not impersonate a translated body.

Use the framework's supported interpolation/pluralization mechanism, not ad hoc concatenation. Preserve placeholder names, case and multiplicity when translations are later introduced. Translate whole meaningful phrases; escape translated text, never execute markup. Store Unicode names safely and do not use ASCII-only validation for ordinary human text.

## Direction, typography and formatting

Phase 1 document lang=en and dir=ltr. Components accept explicit language/direction where needed and use logical margin/padding/border/alignment. Prepare to change the shell direction independently from embedded content direction. Isolate email addresses, URLs, IDs and locale codes with LTR/bdi semantics; isolate untrusted mixed-direction display names. Do not blanket-mirror logos, checkmarks or non-directional icons.

Inter via Google Fonts is the primary Latin font, with system/script/emoji fallback. Test Arabic/Hebrew and CJK/Indic glyph coverage; an installed font is not linguistic review. Long labels wrap without hiding essential controls. Locale-specific fonts can be added later through the same typography owner after approval.

Store technical instants consistently in UTC; display dates/numbers through explicit locale/timezone formatting. State timezone when users enter meaningful date/time values. Do not copy the old CMS's UTC-only scheduling interface into unrelated screens. English-only does not justify hardcoded number/date assembly.

## Readiness acceptance

Use test-only en/tr/ar/he and long pseudo-text fixtures for shared components, input direction, focus order, logical layout, mixed punctuation and responsive wrapping. No production language switch is needed for testing. Verify escaped placeholders and stable keys. Before releasing any additional language, review native names, translation completeness, plural rules, fonts, RTL, format conventions and native-speaker quality. Future locale URL policy is D-06, not authorization to prefix Phase 1 routes.
