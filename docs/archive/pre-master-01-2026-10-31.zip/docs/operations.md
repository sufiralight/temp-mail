# Installation operations

Status: implemented Phase 1 installer; no production deployment performed. [Installation](installation.md) owns state/transitions and [Security](security.md) owns trust controls. Authentication/mail delivery remains Phase 2.

## New development environment

1. Inspect PHP/Composer/Node and locked versions. Verified workstation: PHP 8.5.12, Laravel 13.39.0, Node 24.22.1, npm 11.19.1; exact frontend locks are in package-lock.json. PHP >= 8.3 is required, but only the stated runtime was exercised. Required extensions and Argon2id appear in the live requirements screen. SQLite PDO is the baseline; pdo_pgsql is absent here.
2. Install locked dependencies with project-targeted Composer and `npm ci --ignore-scripts`, then `npm run build`. Check Composer environment variables before use: this workstation had a global COMPOSER override, so explicitly target this project's composer.json. Do not run `composer setup`: its scaffold bootstrap includes key generation and migrations.
3. Copy .env.example only if .env is absent. For a genuinely new environment only, provision APP_KEY privately (for example `php artisan key:generate`). Never regenerate an installed key or expose .env. Set APP_URL to the exact intended host/port. Use APP_ENV=local for loopback development; production must use direct HTTPS and debug off.
4. Provision writable storage/framework/sessions, storage/framework/cache/data, bootstrap/cache and the persistent private installation directory. On Windows restrict ACLs to the operator/PHP service account; POSIX creation uses private modes. Ensure backups/key custody before production.
5. Start the local server and run `php artisan install:authorize` in a private terminal. Use its single-use credential within 15 minutes on /install. Do not log the command output. Inspect requirements → test empty database → enter administrator → review → complete. Do not migrate before the test. No default credentials are supplied.

No .env, real DB, PHP global config, APP_KEY or installed state was changed by the implementation tests. The only new frontend runtime dependency is @alpinejs/csp; PHP dependencies are unchanged.

## Configuration and limitations

INSTALLATION_DIRECTORY defaults to storage/app/private/installation, must be outside public/ and persistent. INSTALLATION_DRIVERS defaults to sqlite. Remote adapters require explicit opt-in plus live qualification; INSTALLATION_DATABASE_HOSTS defaults to localhost/loopback. INSTALLATION_MYSQL_PORT and INSTALLATION_PGSQL_PORT default to 3306/5432. The web form cannot choose arbitrary destinations, paths or DSNs. SQLite always uses application.sqlite inside the private state directory, not the scaffold database/database.sqlite.

File sessions (encrypted), file cache and synchronous queues are deliberately selected before DB access. SESSION_FILES, CACHE_PATH and CACHE_LOCK_PATH can isolate runtime directories; provision them writable first. CACHE_PREFIX alone does not isolate Laravel file cache. Browser tests therefore use actual separate directories. English application/fallback locale is set at boot.

Completed connection selection overrides environment/cached database defaults at request/CLI boot, using an opaque driver and lazy runtime decryption so config:cache cannot persist the installed password. Do not silently switch the installed DB using DB_URL/DB_DATABASE. A read-only .env is supported. Configuration caching must target the intended environment; tests verify actual config:cache serialization and cached restart/query precedence in a disposable directory. On Windows use a project-relative APP_CONFIG_CACHE override for test caches; Laravel's default absolute-cache prefixes do not recognize drive-letter paths. Full production deployment/reload rehearsal remains operator work. Laravel's normal cached environment configuration still contains application secrets such as APP_KEY: keep bootstrap/cache private and protected.

Use ordinary short-lived PHP workers on one persistent host. Multi-replica, ephemeral disk, Octane and reverse-proxy installation are not supported. Setup rejects forwarded headers and noncanonical hosts; no arbitrary trusted proxy configuration is enabled. Use direct production HTTPS or a restricted tunnel to loopback development. A proxy silently stripping all headers must not be mistaken for a secure topology; provision an appropriate operator-controlled access path.

Remote adapters currently use bounded connect timeouts and framework connectors. Their TLS/permissions/version matrix is not production-qualified. SELECT/empty-schema testing cannot certify DDL privileges; finalization performs actual migrations and refuses unsafe partial recovery. Do not enable a remote production driver until its deployment is reviewed and tested. No real SMTP transport, queue worker, scheduler, Cloud resource or deployment is configured.

## Local installer address and blocked-access diagnosis

On 2026-10-31 the reported URL was http://127.0.0.1:8000/install while .env configured APP_URL=http://localhost:8000. Read-only inspection found `php artisan serve` and its PHP child bound to 127.0.0.1:8000, no Vite process/hot file and no cached configuration. These two hostnames can reach that same listener but are intentionally not interchangeable in the installer. Direct localhost access returned 200/authorization form; the IP alias returned 403 specifically at the hostname equality check, before ownership or DB handling. This was not evidence of a reverse proxy.

Secure local procedure with the current configuration:

1. Keep APP_URL=http://localhost:8000. Start the Laravel server with `php artisan serve --host=127.0.0.1 --port=8000` if it is not already running; keep the listener on loopback.
2. Open **http://localhost:8000/install** directly and refresh the page. The listener binding can be an IP while the HTTP Host must match configured localhost. Do not use Vite's asset port, an IP alias or a forwarded development gateway as the wizard URL.
3. Use `php artisan install:authorize` privately and enter the one-use credential on that exact canonical origin. Opening the page alone never grants setup authorization. Do not generate grants for a completed instance, remove locks or change APP_KEY.
4. If a different canonical origin is actually needed, deliberately configure its exact host/port, clear stale configuration cache for that environment and restart the local worker; then use that single origin consistently. Do not add wildcard aliases or auto-trust forwarding headers. This investigation did not rewrite .env or installation state.

The blocked page now distinguishes host mismatch, port mismatch and forwarding headers. On local/testing requests whose raw REMOTE_ADDR is loopback, it shows an escaped allowlisted connection summary and a recovery link built solely from a validated APP_URL origin. It never shows header values, query strings, cookies, setup grants, DB credentials or keys. Remote clients cannot enable these local details by spoofing X-Forwarded-For. Requests outside that local scope receive safe explanation and operator guidance only.

A direct diagnostic request recorded Host=localhost, port=8000, raw peer=127.0.0.1, zero trusted proxies and only the deliberately injected x-forwarded-for header name; it remained 403. An unforwarded request to the configured origin shows the authorization form, not administrator/database access. Authorization, CSRF, expiry and completion locking are unchanged.

### If a reverse proxy becomes necessary

Current setup still rejects forwarded requests. A separate deployment review must define exact trusted proxy IPs/CIDRs (never wildcard trust), edge stripping/replacement of client-supplied forwarding headers, canonical host/scheme/port validation, TLS, origin firewall restrictions, operator setup authentication and single-host persistent lock/storage compatibility. Review/test spoofed headers from both trusted and untrusted peers, conflicting headers, CSRF/session boundaries and post-install locking before enabling any proxy installer path. Do not merely strip headers in a loopback proxy and call the connection trusted.

## Interrupted installation and recovery

Never delete sentinels/state, reset databases, use migrate:fresh or change APP_KEY to recover. Back up the original target and private state first.

- Before migrations: let authorization expire, then issue a new private grant. It clears obsolete proof/pending administrator, not target data. Test the candidate again.
- After migration begins: inspect the original target. `php artisan install:authorize --resume` accepts only a complete expected schema/migration history on the encrypted original connection. It restores a short owned session and preserves the pending/committed original administrator. A partial migration is not blindly rerun; repair the original schema/migration history under operator review and backup, then resume. No automated destructive repair exists.
- Database receipt committed but marker/state disagree: `php artisan install:seal` revalidates installation UUID, schema/history and receipt's Super Admin, then reconciles completion files only. It does not migrate or create/change users.
- Missing/corrupt state or lost key: restore matching encrypted state, original key and DB backups. Fail closed while investigating. A completed DB outage never authorizes a new install.

Keep DB, complete private installation directory, original key/environment and relevant runtime configuration in a coordinated encrypted/restricted backup set. Define retention and restore order; rehearse an isolated restoration before production claims. Power-loss durability depends on filesystem guarantees in addition to atomic writes/fsync. Completed installation cannot be reopened through the web.

## Validation and evidence

See [Testing](testing.md). Automated tests use isolated SQLite/state; Chrome fixtures also isolate sessions/cache and never use real accounts. Actual application installation, live remote engines, mail delivery, production configuration caching/recovery and deployment remain unverified. No WCAG, security or production-readiness certification is implied.
