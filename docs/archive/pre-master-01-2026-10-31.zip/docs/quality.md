# Quality and delivery gate

Status: normative workflow. [Testing](testing.md) owns cases and evidence; [Accessibility](accessibility.md) owns WCAG criteria. Do not duplicate their checklists as new policy.

| Independent check | Evidence | Limitation |
| --- | --- | --- |
| Functional correctness | Relevant isolated validation/authorization/persistence/failure/concurrency tests | Does not prove visual quality |
| Visual coherence | Actual rendered hierarchy/alignment/readability/states in themes/viewports | Does not prove task completion or WCAG |
| Task flow | Primary task and recovery walkthrough with observed friction | Does not equal formal user research |

Before implementation read the scope/topic owners and inspect real code/components. Resolve dependent decisions, state a brief for substantial UI work and build a bounded working reference before propagating presentation. Current Phase 1 references are installer forms and the honest login handoff; auth/dashboard/settings references belong to Phase 2. Do not copy the old Dashboard → Posts → editor sequence requiring deferred CMS.

Before delivery, verify every changed control reaches a real outcome, security boundaries hold, safe values/data are preserved, shared components use the single token/interaction owner and relevant checks pass. Record evidence/limits and update owners. Do not call work premium, accessible, faster or complete just because a build/page renders.

For documentation-only work: read originals first, preserve useful history, validate local links/anchors, review unique ownership, contradictions, implementation claims, missing dependencies and phase boundaries, and ensure only documentation/instruction artifacts changed. Do not run feature tests to imply new product validation. Commit/push only if requested for this delivery.

Historical Phase 0 ended when its documentation/archive checks passed. The subsequent Phase 1 request authorizes installer/foundation implementation only. Current acceptance is a real authorized, verified, durable setup → locked → honest login handoff, with the tests/build/browser/documentation evidence in Testing. Do not begin Phase 2 or deploy as part of this delivery.
