# Canonical Phase 1 scope

Status: Phase 1 implementation authorized by the subsequent Foundation & Secure Installation Wizard request. This request narrows the immediate delivery to foundation, installer, roles data model, installer design components and tests. Authentication, registration, reset, verification, account settings and dashboards in the original roadmap below move to Phase 2. Only an honest `/login` handoff is included; no working authentication form or dashboard placeholder route.

| Approved module | Required outcome | Owner |
| --- | --- | --- |
| Foundation | Laravel 13 SSR, private configuration, security/error boundaries and isolated tests | [Architecture](architecture.md) |
| Installer | Restricted `/install`, server-side database verification, initial Super Admin, completion lock and safe retry | [Installation](installation.md) |
| Authentication — Phase 2 | Public registration, login/logout, forgot/reset password and email verification | [Identity](authentication-authorization.md) |
| Authorization — Phase 2 capabilities | Phase 1 prepares roles/default User; full role access enforcement follows with identity | [Identity](authentication-authorization.md) |
| Dashboards — Phase 2 | Separate protected admin/user destinations with truthful data | [Dashboards](dashboards.md) |
| Account settings — Phase 2 | Self-only name, password, appearance and verification status/recovery links | [Account](account.md) |
| Shared design system | Blade/Tailwind/Alpine/Vite, premium teal, Inter, three themes and responsive accessible states | [UI system](ui-system.md) |

Initial UI, errors and notifications are English. Prepare the 30-language catalog and RTL/LTR per [Internationalization](internationalization.md); readiness does not mean shipping translations or Languages management. WCAG 2.2 AA is a target, never an unverified claim.

## Future boundary

CMS, Images library, Languages management, Temp Mail Engine, subscriptions and billing are future phases. Public CMS routes, rich editor, SEO/revisions, mailbox/homepage product UI and production deployment are excluded. Do not add their tables, packages, navigation, fake statistics or inactive controls. Requirements are retained in [Future requirements](future-requirements.md).

Photos/preset galleries, email-address changes, MFA, social login, user/role management screens, impersonation, tenancy, API tokens and account deletion are outside the immediate baseline; they require explicit approval. Three roles do not imply a role-management module. Admin provisioning needs a reviewed operator mechanism (D-05 in [Decisions](decisions.md)).

## Dependency order

1. Installer D-01/D-02 are resolved in Decisions. Identity delivery D-03 remains a Phase 2 gate.
2. Foundation: pre-database sessions/cache, private state, security/errors, English catalogs and design primitives.
3. Installer verification/completion, then identity persistence and authentication.
4. Phase 2: registration/reset/verification and role enforcement; real configured delivery before claiming email flows work.
5. Phase 2: dashboards and account settings using shared components.
6. Security/concurrency, native fallback, responsive and accessibility acceptance.

Public account routes cannot operate against uninstalled state. Future verification gating must retain notice/resend/logout/recovery access. Scope expansion updates this owner first; old approvals do not expand this rebuild. Phase 1 currently delivers installer ownership authorization, not full user-role authorization. The /login handoff is an informational page only.
