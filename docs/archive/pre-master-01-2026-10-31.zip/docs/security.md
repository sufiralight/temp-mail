# Security requirements

Status: common security requirements. The installer subset is implemented as specified in [Installation](installation.md); identity/session authentication controls below remain Phase 2 requirements. This is not a security certification. [Testing](testing.md) owns actual evidence.

## Threat boundaries

Treat visitors, client fields/IDs, cookies, Host/forwarded headers and third-party responses as untrusted. Address installer takeover, privilege escalation, account takeover/enumeration, CSRF, XSS, secret disclosure, replay and concurrent completion. Host/operator compromise requires operational controls beyond web authorization.

Validate server-side, persist explicit field allowlists, bind queries and allowlist sorts/locales/redirects/configuration. Escape untrusted Blade output; no raw user HTML or Alpine x-html. Mutations use framework CSRF; logout is POST. Signed email verification GET is a narrow exception with authentication, expiry, signature and current-identity checks. Check every endpoint, not just navigation.

Enforce [Identity](authentication-authorization.md) capabilities and ownership. Public registration/profile requests cannot assign roles, verification state or install flags. Recheck sensitive state from authoritative records. Super Admin is not a global bypass around ownership/security.

## Secrets and sessions

Use Laravel hashing, encryption, sessions, password broker and signed verification, never custom cryptography. Do not put passwords, DB credentials, tokens or installer grants in source, logs, analytics, flash input, URLs or browser storage. Never repopulate secret fields. Persisted installer credentials require encryption with a privately provisioned APP_KEY and restricted storage. Never regenerate installed keys.

Explicit URL exception: framework emailed reset and signed verification links contain token/signature material. Use canonical configured origins and production HTTPS, not untrusted Host input. Redact sensitive paths/queries from application/proxy/provider logs; use no-referrer/no-store on those flows and no third-party instrumentation. Reset tokens are hashed at rest, expire and are single-use. Verification binds the authenticated identity/current address.

Regenerate sessions at login; logout invalidates session and CSRF state. Password change/reset revokes persistent login credentials and other sessions per Identity. Cookies are HttpOnly, secure under HTTPS and use a deliberate SameSite policy. Never log session IDs. Throttle login, registration, resets, verification resend and installer probes/completion with actor/network-aware keys; avoid easy global account lockout.

Use generic login/reset outcomes to reduce enumeration. Registration duplicate-address behavior is D-08; resolve before implementation. Require recent password confirmation for password changes and future sensitive privilege/security mutations.

## Installer and infrastructure

An operator-controlled access gate precedes every wizard page/probe; session/CSRF alone cannot prevent first-visitor takeover. [Installation](installation.md) owns transitions. Constrain probe hosts/ports or private SQLite paths, bound timeouts and sanitize errors. No arbitrary DSNs/options/paths or internal-network scanning. Use expiry, live revalidation and durable concurrency controls. Uncertain completion state fails closed.

Installer origin checks compare configured host and port without local alias expansion. Forwarded/real-IP headers cannot establish a trusted peer or setup ownership. Local blocked-access diagnostics require local/testing mode and a raw loopback REMOTE_ADDR, independent of X-Forwarded-For. They expose only escaped host/port/peer, recognized header names and trusted-proxy count; never values, queries or credentials. The actionable canonical link is built only from validated configuration without userinfo/query/fragment. [Operations](operations.md#local-installer-address-and-blocked-access-diagnosis) records the direct local path and the separate review required for any proxy model.

Plan production CSP with self/nonce scripts, no unsafe-eval or blanket unsafe-inline scripts, constrained form/base/object/frame sources and minimal connect/image origins. Use bundled Alpine CSP; test its supported expressions. Specifically allow Google Fonts CSS/font origins with fallback. Never ship HMR allowances/public hot state. Require framing denial, nosniff and deliberate referrer/cache headers on errors too; sensitive responses are private/no-store. HSTS requires a correctly configured HTTPS deployment.

Only public/ is web-accessible. Environment, installation state, databases, uploads, logs, backups and QA output stay private. Old avatars/media docs authorize no uploads. Future uploads require bounded types/signatures/dimensions, randomized paths, private authorization and cleanup; static SVG icons do not justify uploaded SVG.

Production requires trusted host/proxy configuration, HTTPS, secure cookies, APP_DEBUG=false, least-privilege DB credentials and recovery rehearsal. Mail secrets belong to the operator; log/array are not production identity delivery. Tests use fakes. [Operations](operations.md) owns runtime/delivery choices. Phase 0 establishes no security certification or production readiness.
