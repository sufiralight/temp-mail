# Testing standard and evidence policy

Status: Phase 1 installer evidence below; the broader identity/dashboard matrix remains Phase 2 acceptance. Old results stay in the [archive](archive/README.md) and are not reused. Phase 0's no-test statement describes that earlier documentation-only delivery.

## Isolation and method

Use existing PHPUnit infrastructure for behavior; no additional test framework/browser package without demonstrated need and authorization. Tests use disposable DBs, isolated config/install state/cache/session namespaces, fake disks and fake notifications/transports. Assert the test target cannot load real installed state before mutation. Browser fixtures must reject non-disposable targets; never send real messages or reuse production credentials. Do not execute archived scripts: their files/fixtures may not exist.

Test observable requirements and failure boundaries, not tests that mirror private implementation. Use unit tests for focused logic and HTTP/database integration tests for security/workflows. Exercise CSRF through a real protected HTTP boundary because test middleware may bypass it. Run relevant checks after actual changes; broaden when shared/security impact requires it, not by habit.

## Required acceptance matrix

| Area | Required behavior/security evidence |
| --- | --- |
| Foundation | Uninstalled boot without DB; safe errors, private state isolation and no accidental runtime mutation |
| Installer | Access gate, CSRF, ordering/proof binding/expiry, changed settings, failed connection/permissions, empty-target guard, host/path constraints and blank secrets |
| Completion | Two competing clients, duplicate requests, lock contention, crash at each checkpoint, committed-user retry, partial DDL, marker/config failure and outage after completion; no data loss/second Super Admin |
| Registration | User-only assignment, malicious role/verified/owner input, email normalization/uniqueness races, password boundaries and verification dispatch failure |
| Sessions | Login fixation protection, intended URL abuse, generic failure/throttle, POST logout, CSRF state and no sensitive cached back navigation |
| Password reset/change | Wrong/expired/replayed token, confirmation/current password, no secret flash/logging, persistent token rotation and multi-browser revocation; retained current session only for self-change |
| Verification | Signed URL tampering/expiry/cross-user/current email, resend throttle, already verified idempotence, failure/retry and protected dashboard gating |
| Authorization | Guest, unverified and each verified role against every protected endpoint/mutation; deny unknown roles and spoofed IDs |
| Dashboard/account | Actual data, separate destinations, self-only name/password, safe section/error routing and native forms; no future-module controls |
| Design/theme | Light/Dark/System initial paint, reload/live OS/cross-tab/storage failure, controls/password visibility/focus and no duplicate handlers |
| I18n/accessibility | English catalog keys, test-only long text/ar/he direction, Unicode/mixed text, keyboard/screen reader, contrast, reflow/zoom and reduced motion |

Concurrency tests must use genuinely independent processes/connections where needed; a mocked lock is not proof of cross-process safety. SQLite-only tests cannot establish MySQL/MariaDB/PostgreSQL behavior. Test actual supported engines selected under D-01 with isolated targets before claiming compatibility. Configuration/DDL failure tests must preserve populated foreign data.

## Rendered checks

Production Vite build when assets/UI change, relevant PHP tests and formatter checks when code changes. Run only commands present in the current project; `npm run check:ui`, old Playwright scripts and CMS fixtures are not available just because history names them. Use disposable view compilation if required. No feature implementation or test scaffolding is created in Phase 0.

Inspect actual installer/auth/dashboard/settings output at desktop and 320/360px widths, both palettes, System behavior, 200% text/400% zoom, keyboard/representative screen reader and no-JS core forms. Test font failure, error/retry and asynchronous states where they actually exist. Check console/CSP errors. Source guards/automated scores supplement, never replace, manual accessibility and task review.

## Evidence record format

For each implementation delivery record date, commit/source state, environment/versions, exact command or manual scenario, isolated target, result/count, reviewed screens/viewports/themes/input modes, findings and unresolved gaps. Separate functional, visual and task-flow results. Store private QA artifacts outside public/source delivery; sanitize secrets. Never copy old counts, Lighthouse scores or contrast ratios into a new pass. A transport fake is not SMTP delivery; screenshots are not usability acceptance or WCAG conformance.

Documentation changes instead check link targets/anchors, unique ownership, scope boundaries, contradiction scans, archival integrity and actual changed paths. Record Phase 0 results in [Audit](phase-0-audit.md).

## Executed Phase 1 evidence — 2026-10-31

Source: working tree based on bbcb461, installer-only delivery. PHP 8.5.12/Laravel 13.39.0/PHPUnit 12.5.42, Node 24.22.1/npm 11.19.1, Alpine CSP 3.17.5, Tailwind 4.3.3, Vite 8.3.5/Laravel Vite plugin 3.2.0. Tests use private random storage/framework/testing/install-* SQLite/state directories, array test sessions/cache and fake fixture credentials. Child processes inherit only their isolated target; no installed DB is loaded.

- `php artisan test`: **31 passed, 248 assertions**, including a real PDO failure, populated-data preservation, grant guessing/replay/expiry/ownership, missing-key requirements, host/forwarded/insecure transport, proof expiry/invalidation, role tampering, blank secret validation, completion locks and no extra administrator. CSRF test explicitly disables Laravel's unit-test bypass and receives sanitized 419 without the submitted credential/trace.
- Separate PHP processes exercise actual OS lock contention and simultaneous completion: one winner and exactly one administrator/receipt. Failure injection at marker write preserves a committed account for explicit resume. Tests also cover completed-schema crash checkpoint, partial-DDL refusal, missing/corrupt state, missing completion marker/reseal and restart precedence. An actual isolated config:cache and cached restart query confirm decrypted installed password is absent from the cached config while the original DB is selected over conflicting environment defaults.
- `php vendor/bin/pint --dirty`: applied project formatting, no reported remaining formatting errors. `php C:/composer/composer.phar validate --strict` with COMPOSER explicitly set to this project's composer.json: valid. No PHP dependency was installed/changed.
- `npm run build`: passed; the later single-icon disclosure build measures CSS 21.46kB raw/5.59kB gzip and JS 71.33kB raw/23.36kB gzip. `npm ls --depth=0` records actual versions; optional @laravel/multiplex is unavailable on this platform and not used by the installer. npm install audit reported zero vulnerabilities at install time, not a perpetual guarantee. No existing check:ui script exists, so none is falsely claimed.

Chrome uses the supplied Playwright runtime, not a new application/browser-test dependency. `tests/browser/installer.cjs` starts a fresh loopback PHP server with a fixed test-only key and separate private DB, state, SESSION_FILES, CACHE_PATH and CACHE_LOCK_PATH; refuses an unexpected fixture prefix and removes its fixture/server afterward. CACHE_PREFIX alone cannot isolate file cache; an initial shared-cache run hit production throttles and the fixture was corrected rather than weakening limits. Run JavaScript modes sequentially on separate fixtures:

```powershell
$env:PLAYWRIGHT_MODULE = 'path-to-existing-playwright-package'
node tests/browser/installer.cjs
$env:NATIVE_ONLY = '1'
node tests/browser/installer.cjs
Remove-Item Env:NATIVE_ONLY
```

Both complete flows passed: grant → actual requirements → empty SQLite probe → pending administrator → final migration/creation → locked installer → honest login handoff, with JavaScript enabled and disabled. Real browser HTTP POST without CSRF returned 419. Checks cover one h1, associated native labels, duplicate IDs, 1440/360px reflow and 320px no-JS handoff. Enhanced mode also verifies Show/Hide password, Light/Dark/System live OS changes, blocked localStorage fallback and cross-tab theme synchronization without Alpine/CSP errors. Screenshots use empty password fields for visual previews.

Visual review inspected actual Light desktop requirements/admin and Dark mobile admin output. Task review exercised each next action, native fallback and locked-state recovery information. The skip-link presentation and screenshot scroll/hydration setup were refined. Review also caught an Alpine label-context issue: password toggle labels now initialize from their component root, and the browser audit checks visible buttons for accessible names. QA screenshots remain ignored under storage/framework/testing/phase1-review; they are not versioned product assets or usability certification.

Documentation/delivery checks: 228 local Markdown links resolved, all 33 historical archive hashes remain unchanged, git diff --check passed and PHP manifest/lockfiles are unchanged. Secret/runtime/database/dependency/QA paths remain ignored. Current changed-file inventory is in [Phase 1 report](phase-1-report.md); no commit/push is included in this delivery.

Limits: only SQLite is end-to-end qualified. No live MySQL/MariaDB/PostgreSQL installation/concurrency/TLS matrix, real SMTP, production proxy/Cloud/multi-host topology, power-loss filesystem test, production restore rehearsal, Safari/Firefox/native screen-reader audit or complete WCAG 2.2 AA conformance check. 200% text/400% browser zoom and full 30-language rendering remain unmeasured. Identity/mail/dashboard/account controls are Phase 2 and were not implemented or claimed tested. No real application installation, environment/key rewrite or deployment occurred.

Icon-selector follow-up (2026-10-31): replaced the appearance select with a labelled native sun/moon/monitor radio group. Production build, diff check and the existing isolated Chrome flow passed again, including native arrow-key selection, Light/Dark/System, cross-tab and blocked-storage behavior, desktop/mobile reflow and control labels. Desktop and mobile Dark screenshots were visually reviewed. PHP behavior was unchanged; its suite was not rerun for this presentation-only change.

Subsequent visual refinement: the permanent segmented group was replaced by one native details/summary icon disclosure. Its compact list retains labelled radios and checkmarks. The Chrome flow passed with keyboard opening, native radio selection, closing after selection/reselection, Escape, restored trigger focus and existing theme behavior. No new UI dependency or backend behavior was introduced.

## Installer access-block investigation — 2026-10-31

Root cause reproduced on the actual local Laravel server: configured APP_URL=http://localhost:8000, user-reported URL=http://127.0.0.1:8000/install. The middleware's exact hostname comparison rejected the alias before authorization; it used the same old message as forwarded-header rejection, obscuring the cause. Process/config inspection found artisan serve and PHP -S on 127.0.0.1:8000, no Vite process/hot file and no cached configuration. The original Windows Firefox address could not be inspected by the native browser tool; the reported address came from the user, not an inferred tab. The subsequently available in-app browser at the canonical localhost URL visibly showed the genuine authorization form.

Read-only direct HTTP checks: localhost:8000/install returned 200 with authorization form; 127.0.0.1:8000/install returned 403/host mismatch; canonical origin with injected X-Forwarded-For remained 403/forwarded-header rejection. Safe local response metadata recorded actual host localhost, port 8000, raw peer 127.0.0.1, trusted proxy count 0 and the injected header name only. No header/cookie/query/credential values were dumped. No real grant, DB mutation or install completion was performed.

`php artisan test`: **36 passed, 295 assertions** (31 existing tests plus five focused access/UX cases). Cases verify canonical authorized access, local-alias recovery link, wrong-port explanation, every recognized forwarded header even in an authorized session, remote spoof denial/no local diagnostics, and no credential-bearing configuration URL link. Existing expiry, replay, CSRF, concurrency, completion-lock and recovery checks still pass. `php vendor/bin/pint --dirty`, `npm run build` and `git diff --check` passed. No authorization/locking/CSRF exemption, wildcard proxy trust, .env/key/state change or extra dependency was introduced. See [Operations](operations.md#local-installer-address-and-blocked-access-diagnosis) for the supported direct local method and the separately reviewed proxy model requirements.
