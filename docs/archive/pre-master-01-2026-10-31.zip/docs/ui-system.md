# Premium design-system specification

Status: shared token system and installer component subset implemented in Phase 1. Admin/user shells and future component families remain planned. [UX](ux.md) owns task flow; [Accessibility](accessibility.md) owns conformance targets. Premium means precise hierarchy, restraint and dependable interactions, not copying Stripe/Vercel/Linear or using a template label.

## Identity and token ownership

Temp Mail SaaS uses turquoise/teal as its primary identity with neutral surfaces, quiet borders, crisp typography and limited elevation. Avoid competing mint/green/teal themes, ornamental gradients, excessive shadows and a card around every field. Teal is an accent/action family, not a substitute for success/error semantics.

`resources/css/app.css` is the sole runtime token owner; Tailwind uses its semantic variables. The defaults below are implemented; runtime values remain authoritative and significant changes update this owner. No page-level literal palette overrides.

| Token | Light starting value | Dark starting value | Use |
| --- | --- | --- | --- |
| canvas | #F8FAFC | #0B1215 | Document background |
| surface | #FFFFFF | #111D22 | Primary panels/forms |
| elevated | #F1F5F9 | #182A30 | Menus/dialogs |
| ink | #0F172A | #F1F5F9 | Primary text |
| secondary | #475569 | #CBD5E1 | Secondary text |
| muted | #526176 | #A8B8C5 | Supporting text, never opacity-only |
| line | #DCE4E9 | #344952 | Decorative separators |
| control-line | #64748B | #8096A0 | Interactive boundaries |
| accent | #0F766E | #5EEAD4 | Primary controls/links |
| accent-hover | #115E59 | #99F6E4 | Hover state |
| on-accent | #FFFFFF | #042F2E | Text on accent |
| focus | #0F766E | #5EEAD4 | Visible outline with offset |
| success / subtle | #166534 / #F0FDF4 | #86EFAC / #10291F | Confirmed outcome |
| warning / subtle | #854D0E / #FEFCE8 | #FDE047 / #302714 | Caution |
| error / subtle | #B91C1C / #FEF2F2 | #FCA5A5 / #35191F | Error/destructive |

Values are candidates, not contrast evidence. Measure every actual foreground/background/state pairing before use. Disabled controls must remain understandable; never use muted text below required contrast for active content. Links in body text are underlined or otherwise identifiable beyond color.

## Typography and layout

Use Google Fonts Inter (400/500/600/700), display=swap, with ui-sans-serif/system and script/emoji fallbacks. One document head owns font links, metadata, theme bootstrap and Vite. Do not fetch fonts independently per component or claim Inter covers every script. If blocked/offline, tasks remain usable with fallback and minimal layout shift.

Starting type scale: body 16px/1.5, compact supporting text 14px/1.5, labels 14px/1.4 medium, h1 28–32px/1.2 semibold, h2 20–24px/1.3, h3 18px/1.4. Avoid essential microcopy below 14px. Use fluid wrapping, not fixed-height headings. Layout/spacing use a 4px scale (4/8/12/16/24/32/48); controls default to 44px minimum height, field/button radius 8px, grouped surfaces 12px, dialogs 16px. Radii express grouping, not global pill styling.

Desktop app shell: sidebar about 248px, header minimum 64px, content max 1280px with 24–32px padding. Below 768px use mobile navigation and 16px padding; intermediate widths adapt content rather than force overflow. Guest/auth forms max 448px; installer may use up to 640px for step context. Settings max 896px. These are starting constraints: verify long copy, 320px reflow and zoom. Use logical edges/gaps. One primary action per task context; whitespace/dividers group simpler work before panels.

## Themes

One owner resolves Light, Dark or System. System is the default; follows live device changes only while selected. Store only allowlisted appearance preference in browser-local storage; catch unavailable/corrupt storage, coordinate same-origin tabs and keep header/settings controls synchronized. Do not persist secrets or forms there. Early nonce-compatible bootstrap prevents wrong-theme flash; server/no-JS CSS supports device preference. The three choices have visible labels/selection and keyboard-operable native semantics. Test initial paint, reload, OS change, cross-tab and blocked storage.

The header uses one quiet 44px icon disclosure showing the selected sun, moon or monitor. Opening it reveals a compact, labelled native radio group with icons, text and a selected checkmark. Choosing a theme or pressing Escape closes it and restores trigger focus; outside clicks dismiss without stealing focus. It reuses the existing theme owner and hides without JavaScript. The same control applies on desktop and mobile; no permanent three-way segmented toolbar remains.

## Component responsibilities (installer subset implemented)

| Shared responsibility | Contract |
| --- | --- |
| Document head | One font/theme/Vite/meta and nonce owner |
| Guest/install, admin and user shells | Common identity/tokens; separate authorized navigation composition |
| Page heading | One h1, concise context and real primary action |
| Buttons | Primary, secondary, quiet and danger; native button type; real disabled/busy state |
| Fields | Unique IDs, labels/help/errors, correct autocomplete and safe value preservation |
| Password field | One visibility owner; named toggle, announced state, no changed value/autocomplete |
| Feedback | Persistent server notices/error summary; polite asynchronous status; no false success |
| Subnavigation/disclosure | Real links with current state; native details for optional content |
| Dialog/menu | Native semantics where possible; label, keyboard, focus lifecycle and return |
| Appearance/icons/tooltips | One theme owner; icons consistently sized/stroked and meaningfully named |
| Empty/loading states | Actual task state, explanation and working recovery/action |

Create only components needed by approved screens, with small explicit APIs and prepared data. Use a single consistent local SVG icon style; decorative SVG is aria-hidden, icon-only buttons have accessible names. Tooltips supplement names, appear on hover/focus, dismiss with Escape and do not hide essential guidance. Reveal-password icons describe the action/state rather than rely on shape. No remote avatar service or additional icon package by default.

Tables/pagination, rich editor, media picker and translation management remain deferred until an approved module needs them. Their future appearance reuses this system rather than creating another one. Native forms/links must work without Alpine; enhanced loading must not disable successful payload fields or leave controls stuck after errors/history return. [Quality](quality.md) requires rendered review before acceptance.

Implemented files under resources/views/components: installer-layout, step-indicator, field, input, password-input, select, button, alert, status-indicator and validation-summary. theme-bootstrap.js is the sole pre-paint theme owner; bundled app.js registers Alpine CSP enhancements once. No-JS hides inactive appearance/password enhancements while retaining functional forms and device palette. The retired scaffold welcome/font integration was removed; Google Fonts Inter and fallback are loaded by the shared head.
